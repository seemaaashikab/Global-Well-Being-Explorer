# `styles/` — Stylesheets

This folder contains the single CSS file that styles the entire application. There are no preprocessors, frameworks, or component-scoped style files — just plain CSS using modern custom properties and layout features.

---

## Files

| File | Description |
|---|---|
| `main.css` | Complete application stylesheet — theme variables, layout, components, animations |

---

## Design Principles

The stylesheet follows these core principles, consistent with the data story's visual language:

- **Dark theme** — Deep navy/charcoal backgrounds reduce eye strain during extended data exploration and make coloured data points visually pop.
- **CSS custom properties** — All colours, spacing, radius, and timing values are declared as variables in `:root`, making global restyling possible by changing a single value.
- **No external dependencies** — No Bootstrap, Tailwind, or any other CSS framework. Every rule is hand-authored.
- **Accessibility** — Colour choices maintain sufficient contrast ratios; interactive elements have visible focus states; hover targets are appropriately sized.

---

## CSS Custom Properties (Design Tokens)

All tokens are defined in `:root` and used throughout the file. Modifying these values changes the appearance globally.

### Colours

| Variable | Value | Usage |
|---|---|---|
| `--bg` | `#0d1117` | Page background |
| `--bg-deep` | `#080c11` | Deepest background (hero, footer) |
| `--surface` | `#161b27` | Card / chart panel background |
| `--surface-alt` | `#1e2637` | Slightly elevated surface |
| `--surface-hi` | `#252d42` | Hovered / active surface |
| `--border` | `#2a3349` | Default border colour |
| `--border-light` | `#3a4660` | Lighter border (separators) |
| `--text` | `#dde1ea` | Primary text |
| `--text-muted` | `#7c879f` | Secondary / label text |
| `--text-dim` | `#4a5570` | Tertiary / disabled text |
| `--accent` | `#4fc3f7` | Interactive highlight (links, active states, first radar country) |
| `--accent-dim` | `#2a7fab` | Darker accent (hover, pressed) |
| `--gold` | `#f59e0b` | Stat callout numbers, warnings |
| `--green` | `#34d399` | Positive values, success |
| `--red` | `#f87171` | Negative values, errors |

### Spacing & Shape

| Variable | Value | Usage |
|---|---|---|
| `--nav-h` | `56px` | Fixed navigation bar height — used for scroll offset calculations in JS |
| `--radius` | `8px` | Standard border radius for cards and panels |
| `--radius-sm` | `4px` | Small border radius for buttons, chips, inputs |

### Typography & Motion

| Variable | Value | Usage |
|---|---|---|
| `--font` | `'Segoe UI', system-ui, ...` | Body and UI text |
| `--mono` | `'Consolas', 'Courier New', ...` | Code and numeric displays |
| `--ease` | `0.25s ease` | Default transition duration/easing for hover effects |

---

## Layout Architecture

### Navigation Bar (`.story-nav`)
- Fixed to top, `height: var(--nav-h)`
- Contains section links (`.nav-link`) and a scroll progress bar (`#scroll-progress-bar`)
- Active section link highlighted via `.active` class toggled by `IntersectionObserver` in `main.js`
- Progress bar fills from 0% to 100% as the user scrolls the page

### Hero Section (`#hero`)
- Full-viewport-height intro with the project title and tagline
- Background uses `--bg-deep` to visually separate from chart sections

### Story Sections (`.story-section`)
- Each section corresponds to one or two charts
- Consistent padding and `max-width` container centres content on wide screens
- Section headings use gradient text effect (`background-clip: text`)

### Chart Panels (`.chart-panel`)
- White-surface cards (`background: var(--surface)`) with `border-radius: var(--radius)`
- Subtle `box-shadow` lifts them off the background
- `overflow: hidden` clips SVG content to panel bounds

### Controls (`.controls`, `.ybtn`, `.styled-select`)
- Year buttons (`.ybtn`) are pill-shaped toggle buttons; active state uses `--accent` background
- Dropdowns (`.styled-select`) use custom styling to match the dark theme
- All controls have `:hover` and `:focus-visible` states

### Tooltips (`.tooltip`)
- `position: fixed` so they don't overflow clipped containers
- `pointer-events: none` so they don't interfere with mouse events
- Fade-in via `opacity` transition and `transform: translateY` for a lift effect

### Country Chips (`.chip`)
- Inline flex tags used in the Line Chart's country selector
- Colour-coded via `--chip-color` CSS variable set from JavaScript
- `.chip-remove` spans act as × buttons

### Insight Cards (`.insight-card`)
- Grid of clickable summary cards in the Conclusion section
- Hover and `.active` states trigger a callout strip (`#insight-callout`) with a "Go to chart" link
- Stat numbers (`.insight-num`) are animated with a count-up effect via JS

### Radar Legend (`.radar-legend`)
- Three colour swatches matching the radar polygon colours
- Updates dynamically when countries are selected/deselected

---

## Animations & Transitions

| Element / State | Animation |
|---|---|
| Nav link hover | `color` and `border-bottom` transition, `var(--ease)` |
| Chart panel hover | Subtle `box-shadow` growth |
| Tooltip show/hide | `opacity` + `translateY` over 150ms |
| Year button activation | `background-color` transition |
| D3 chart updates | Handled in JS via `selection.transition().duration(600)` |
| Line chart draw | `stroke-dashoffset` animation (D3) |
| Insight stat numbers | JavaScript count-up (cubic ease-out, 1600ms) |
| Scroll progress bar | Instant width update on `scroll` event |

---

## Responsive Behaviour

- Chart panels use `width: 100%` and `min-height` rather than fixed pixel sizes.
- D3 charts read container width at render time and re-render on `window.resize` (debounced 220ms).
- Navigation collapses gracefully on smaller screens (link text may truncate).
- The layout is primarily designed for desktop-width screens (1200px+) as required for a lab environment, but remains functional at 768px+.