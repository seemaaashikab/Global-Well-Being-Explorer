# `data/` — Processed Datasets

This folder contains the **cleaned, merged, and ready-to-use CSV files** that the application loads at runtime via `DataManager.js`. These files were produced by the EDA pipeline documented in `eda/EDA_notebook.ipynb`.

> Do **not** submit this folder to Canvas — only the application code is required for submission.

---

## Files

### `merged_wb_happiness_2015_2019.csv`
**751 rows · 18 columns**

The primary dataset used by the scatter plot, choropleth map, and bar chart. It merges World Bank development indicators with World Happiness Report scores for the years 2015–2019.

| Column | Type | Description |
|---|---|---|
| `Country` | string | Country name |
| `Year` | integer | Year (2015–2019) |
| `GDP_current_US` | float | Total GDP in current US dollars |
| `life_expectancy_at_birth` | float | World Bank life expectancy (years) |
| `population` | float | Total population |
| `CO2_emisions` | float | CO₂ emissions (kt) |
| `access_to_electricity%` | float | % of population with electricity access |
| `individuals_using_internet%` | float | % of population using the internet |
| `gini_index` | float | Gini coefficient (income inequality) |
| `human_capital_index` | float | World Bank Human Capital Index |
| `Happiness Score` | float | WHR happiness score (0–10) |
| `GDP per Capita` | float | WHR GDP per capita index |
| `Social Support` | float | WHR social support index |
| `Healthy Life Expectancy` | float | WHR healthy life expectancy index |
| `Freedom` | float | WHR freedom index |
| `Generosity` | float | WHR generosity index |
| `Perceptions of Corruption` | float | WHR corruption perception index |
| `Region` | string | WHR world region (back-filled from 2015 data) |

**Coverage:** ~157 countries, 2015–2019 (not all countries have data for all years).  
**Missing values:** `gini_index` and `human_capital_index` are sparse; all others are well-populated.  
**Region note:** Region data was only present in WHR 2015 and 2016 files. `DataManager.js` back-fills missing regions using a 2015 lookup map at load time.

---

### `merged_all_2015.csv`
**145 rows · 28 columns**

A snapshot of 2015 data only, merging all three sources: World Bank, WHO Life Expectancy, and World Happiness Report. Used exclusively by the Radar Chart to provide the richest per-country profile available.

Includes all columns from `merged_wb_happiness_2015_2019.csv` plus:

| Column | Type | Description |
|---|---|---|
| `Life expectancy ` | float | WHO life expectancy (years) |
| `Adult Mortality` | float | Adult mortality rate per 1,000 |
| `infant deaths` | float | Infant deaths per 1,000 |
| `Hepatitis B` | float | Hepatitis B immunisation coverage (%) |
| `Measles ` | float | Measles reported cases |
| `Polio` | float | Polio immunisation coverage (%) |
| `Total expenditure` | float | Government health expenditure (% of GDP) |
| `Diphtheria ` | float | Diphtheria immunisation coverage (%) |
| `GDP` | float | WHO-reported GDP per capita (USD) |
| `Schooling` | float | Average years of schooling |
| `Status` | string | `Developed` or `Developing` |

---

### `wb_trends_1990_2023.csv`
**9,292 rows · 6 columns**

Long-range World Bank trends used exclusively by the Line Chart. Covers up to 274 countries across 34 years.

| Column | Type | Description |
|---|---|---|
| `Country` | string | Country name |
| `Year` | integer | Year (1990–2023) |
| `GDP_current_US` | float | Total GDP in current US dollars |
| `life_expectancy_at_birth` | float | Life expectancy at birth (years) |
| `population` | float | Total population |
| `CO2_emisions` | float | CO₂ emissions (kt) |

**Coverage:** ~274 countries, though early years (pre-2000) have sparser data.

---

### `happiness_2015_2019.csv`
**782 rows · 9 columns**

The happiness-only series for 2015–2019, used by the Bar Chart when computing regional averages. Retains all WHR happiness factor columns but excludes World Bank indicators.

| Column | Type | Description |
|---|---|---|
| `Country` | string | Country name |
| `Year` | integer | Year (2015–2019) |
| `Happiness Score` | float | Overall happiness score (0–10) |
| `GDP per Capita` | float | WHR GDP per capita index |
| `Social Support` | float | Social support index |
| `Healthy Life Expectancy` | float | Healthy life expectancy index |
| `Freedom` | float | Freedom to make life choices |
| `Generosity` | float | Generosity index |
| `Perceptions of Corruption` | float | Perceptions of corruption (inverted for display) |
| `Region` | string | WHR world region |

---

## How These Files Are Generated

The EDA pipeline (see `eda/README.md`) performs the following steps:

1. Load raw CSVs from `raw_data/`
2. Standardise column names across WHR years (2015–2019 have different headers)
3. Merge World Bank + WHR on `Country` and `Year`
4. Merge all three sources on `Country` for the 2015 snapshot
5. Export four CSV files to this folder

The pipeline is documented in `eda/EDA_notebook.ipynb` and can be re-run to regenerate all files from the original raw sources.

---

## How the Application Loads These Files

`DataManager.js` loads all four files concurrently using `Promise.all([d3.csv(...), ...])`. Each file has a dedicated row-parser that:

- Converts numeric strings to JavaScript numbers (or `null` for blanks)
- Renames raw CSV column headers to clean camelCase/snake_case JS property names
- Back-fills missing `Region` values from the 2015 region lookup

See `scripts/README.md` for full DataManager documentation.