# `eda/` — Exploratory Data Analysis

This folder contains the Jupyter notebook used to clean, merge, explore, and export all datasets for the Global Well-Being Explorer project.

---

## Contents

| File | Description |
|---|---|
| `EDA_notebook.ipynb` | Main EDA notebook — data loading, cleaning, merging, visualisation, and CSV export |

---

## Purpose

The EDA notebook serves two roles:

1. **Data pipeline** — Loads the three raw source datasets, standardises them, merges them, and exports four clean CSV files to `data/` that the application uses at runtime.
2. **Analytical foundation** — Performs exploratory analysis to identify key insights that shaped the data story, visualisation choices, and interaction design.

---

## How to Run

### Requirements

```bash
pip install pandas numpy matplotlib seaborn scipy jupyter
```

### Execution

```bash
# From the project root
jupyter notebook eda/EDA_notebook.ipynb
```

Run all cells top-to-bottom. The final cells export the four processed CSVs to `data/`. If the `data/` folder already contains the latest files, re-running is not necessary.

---

## Notebook Structure

The notebook is organised into 16 sections:

| Section | Title | What It Does |
|---|---|---|
| 1 | Setup | Imports libraries, sets paths |
| 2 | Load Raw Datasets | Reads all files from `raw_data/` into DataFrames |
| 3 | Load Datasets into DataFrames | Standardises WHR column names across 2015–2019 (each year uses different headers) |
| 4 | Preview & Inspect the Data | `.head()`, `.info()`, `.dtypes()` for each dataset |
| 5 | Summary Statistics | `.describe()` for all numeric columns |
| 6 | Missing Values Analysis | Heatmap and percentage breakdown of nulls per column |
| 7 | Temporal Alignment | Aligns year ranges across datasets; resolves overlap (all three datasets share 2015) |
| 8 | Distribution of Numerical Features | Histogram grids for happiness score, GDP, life expectancy, etc. |
| 9 | Correlation Heatmap | Pearson correlation matrix for all numeric features |
| 10 | GDP vs Happiness Scatter Plot (2015) | Confirms log-linear relationship (r = 0.790) — basis for Scatter Chart design |
| 11 | Life Expectancy — Top & Bottom Countries | Bar charts of outlier countries |
| 12 | World Bank Global Trends (1960–2023) | Line plots of GDP and life expectancy over time |
| 13 | Outlier Detection with Box Plots | Identifies extreme values per region |
| 14 | Pairwise Relationships (Happiness Factors) | Seaborn pairplot of all WHR happiness factors |
| 15 | Country Coverage & Overlap | Venn-style analysis of which countries appear in all three datasets |
| 16 | Summary & Key Findings + CSV Export | Summarises insights; exports four CSVs to `data/` |

---

## Key Findings from EDA

These insights directly shaped the data story and visualisation design:

| Finding | Correlation | Visual Response |
|---|---|---|
| GDP vs Happiness is log-linear | r = 0.790 | Log scale x-axis on Scatter Chart |
| Life expectancy strongly predicts happiness | r = 0.743 | Life expectancy axis on Radar Chart and map metric |
| Social support is second strongest predictor | r = 0.651 | Prominent axis on Radar Chart |
| Generosity is the weakest happiness predictor | r = 0.138 | Included on radar but annotated as weak |
| ~30-year gap in life expectancy between richest and poorest countries | — | Highlighted in Line Chart and conclusion section |
| Strong regional clustering in GDP vs Happiness space | — | Region colour coding across all charts |

---

## Exported Files

The notebook's final cells produce the following files in `data/`:

| Output File | Rows | Description |
|---|---|---|
| `merged_wb_happiness_2015_2019.csv` | 751 | World Bank + WHR merged (2015–2019) |
| `merged_all_2015.csv` | 145 | All three sources merged for 2015 only |
| `wb_trends_1990_2023.csv` | 9,292 | World Bank long-range trends |
| `happiness_2015_2019.csv` | 782 | WHR happiness series only (2015–2019) |

See `data/README.md` for full column-level documentation of each file.

---

## Tools Used

| Tool | Version | Purpose |
|---|---|---|
| Python | 3.10+ | Main language |
| pandas | 2.x | Data loading, merging, cleaning |
| numpy | 1.x | Numeric operations |
| matplotlib | 3.x | Base plotting |
| seaborn | 0.13+ | Statistical visualisation |
| Jupyter Notebook | 7.x | Interactive environment |

> **Note:** Per the project brief, no AI-assisted EDA tools were used.