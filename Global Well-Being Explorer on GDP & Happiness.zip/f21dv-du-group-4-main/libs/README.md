# `libs/` — Third-Party Libraries

This folder contains local copies of all third-party JavaScript libraries used by the application. Serving them locally ensures the application works in offline or restricted lab environments without relying on external CDN availability.

---

## Libraries

### `libs/d3/` — D3.js v7

| Attribute | Value |
|---|---|
| Library | D3.js (Data-Driven Documents) |
| Version | 7 (minified) |
| File | `d3.v7.min.js` |
| Licence | ISC (see `libs/d3/LICENSE`) |
| Homepage | https://d3js.org |
| Docs | https://d3js.org/getting-started |

D3.js is the **sole visualisation library** used in this project, as required by the F21DV project brief. It provides:

- SVG-based chart rendering
- Data joins and enter/update/exit pattern
- Scales (`scaleLog`, `scaleLinear`, `scaleBand`, `scaleSequential`, etc.)
- Axes (`axisBottom`, `axisLeft`)
- Geographic projections (`geoNaturalEarth1`, `geoPath`)
- Colour schemes (`schemeTableau10`, `interpolateYlGnBu`, `interpolateViridis`, etc.)
- Transitions and animation (`selection.transition().duration()`)
- CSV loading (`d3.csv()`)
- Statistical helpers (`d3.mean`, `d3.max`, `d3.min`, `d3.group`)
- Zoom behaviour (`d3.zoom`)
- Brush behaviour (`d3.brushX`)

**How it is loaded:**

```html
<!-- index.html -->
<script src="libs/d3/d3.v7.min.js"></script>
```

D3 is loaded as a classic script (not an ES module) so it is available globally as `d3` throughout all module scripts.

---

### `libs/topojson/` — TopoJSON Client v3

| Attribute | Value |
|---|---|
| Library | TopoJSON Client |
| Version | 3 (minified) |
| File | `topojson-client.min.js` |
| Licence | ISC |
| Homepage | https://github.com/topojson/topojson-client |

TopoJSON Client is used exclusively by `ChoroplethMap.js` to decode the world geography file (fetched at runtime from the public `naturalearth-cdn`) into GeoJSON features that D3's geographic path generator can render.

**Usage in code:**

```javascript
// ChoroplethMap.js
const world = await d3.json('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json');
const countries = topojson.feature(world, world.objects.countries);
```

**How it is loaded:**

```html
<!-- index.html -->
<script src="libs/topojson/topojson-client.min.js"></script>
```

---

## Approval

The use of TopoJSON Client was approved by the course lecturer, as it is a geospatial support library required to render the choropleth map — a geography-only utility rather than a charting library. All rendering logic is implemented using D3.js.

No other third-party libraries are used. There is no React, Vue, jQuery, Bootstrap, Chart.js, Leaflet, or any other framework.

---

## Updating Libraries

If a newer version is needed:

1. Download the minified build from the official source or npm.
2. Replace the file in the appropriate subfolder.
3. Verify the global variable name has not changed (`d3`, `topojson`).
4. Update the version number in this README.