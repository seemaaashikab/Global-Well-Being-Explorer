/**
 * BarChart.js
 * Horizontal bar chart comparing average metric values across world regions.
 *
 * This chart is used in the "Regional View" section. It shows one bar per
 * region, sorted by value descending. Each bar is coloured using the shared
 * REGION_COLOURS palette for visual consistency with the scatter plot.
 *
 * Features:
 *  - Horizontal layout so that long region names fit without truncation
 *  - Metric switcher: happiness, GDP index, social support, life expectancy, freedom
 *  - Whisker lines showing the min-to-max range within each region
 *  - Tick marks at the min and max positions
 *  - Value label next to each bar showing the mean and country count
 *  - Click a bar to dispatch the region name to main.js, which filters the scatter
 *  - Click the same bar again to deselect (sends null)
 *  - Animated transitions on data or metric change
 *  - highlight(region) / clearHighlight() for cross-chart interaction
 *  - resize() recalculates dimensions when the browser window changes
 *
 * Data source: DataManager.getRegionAverages(year, metric)
 * Returns: Array of {Region, value, count, min, max}
 */

import { REGION_COLOURS } from './DataManager.js';

/** Axis labels for each metric key */
const METRIC_LABELS = {
    happiness:          'Happiness Score',
    gdp_per_capita_idx: 'GDP per Capita Index',
    social_support:     'Social Support Score',
    healthy_life_exp:   'Healthy Life Expectancy (normalised)',
    freedom:            'Freedom Score'
};

class BarChart {

    #container;
    #svg;
    #g;
    #tooltip;

    #width;
    #height;
    #margin = { top: 24, right: 60, bottom: 56, left: 210 };

    #xScale;
    #yScale;

    #data   = [];
    #metric = 'happiness';
    #activeRegion = null;
    #onRegionSelectCb = null;

    /**
     * @param {string} containerSel
     * @param {string} tooltipSel
     */
    constructor(containerSel, tooltipSel) {
        this.#container = document.querySelector(containerSel);
        this.#tooltip   = d3.select(tooltipSel);
        this.#initSvg();
    }

    /* Public API */

    /**
     * @param {Array}  regionData - From DataManager.getRegionAverages()
     * @param {string} metric     - Metric key (matches regionData[i].value source)
     */
    render(regionData, metric = 'happiness') {
        this.#data   = regionData.filter(d => d.Region);
        this.#metric = metric;
        this.#updateScales();
        this.#drawAxes();
        this.#drawBars();
    }

    /** Dim all bars except the named region. */
    highlight(region) {
        this.#activeRegion = region;
        this.#g.selectAll('.bar-group')
            .transition().duration(300)
            .attr('opacity', d => (!region || d.Region === region) ? 1 : 0.2);
    }

    clearHighlight() {
        this.#activeRegion = null;
        this.#g.selectAll('.bar-group')
            .transition().duration(300)
            .attr('opacity', 1);
    }

    onRegionSelect(cb) { this.#onRegionSelectCb = cb; }

    resize() {
        this.#initSvg();
        if (this.#data.length) this.render(this.#data, this.#metric);
    }

    /*Private */

    #initSvg() {
        const rect = this.#container.getBoundingClientRect();
        this.#width  = rect.width  - this.#margin.left - this.#margin.right;
        this.#height = Math.max(400, rect.height - 32) - this.#margin.top - this.#margin.bottom;

        d3.select(this.#container).select('svg').remove();

        this.#svg = d3.select(this.#container)
            .append('svg')
            .attr('width',  this.#width  + this.#margin.left + this.#margin.right)
            .attr('height', this.#height + this.#margin.top  + this.#margin.bottom);

        this.#g = this.#svg.append('g')
            .attr('transform', `translate(${this.#margin.left},${this.#margin.top})`);

        this.#g.append('g').attr('class', 'x-axis').attr('transform', `translate(0,${this.#height})`);
        this.#g.append('g').attr('class', 'y-axis');

        // Axis label placeholder 
        this.#svg.append('text').attr('class', 'axis-label bar-x-label')
            .attr('text-anchor', 'middle')
            .attr('x', this.#margin.left + this.#width / 2)
            .attr('y', this.#height + this.#margin.top + 48);
    }

    #updateScales() {
        this.#yScale = d3.scaleBand()
            .domain(this.#data.map(d => d.Region))
            .range([0, this.#height])
            .padding(0.28);

        const maxVal = d3.max(this.#data, d => d.max) || 1;
        this.#xScale = d3.scaleLinear()
            .domain([0, maxVal * 1.08])
            .range([0, this.#width]);
    }

    #drawAxes() {
        this.#g.select('.x-axis')
            .transition().duration(600)
            .call(d3.axisBottom(this.#xScale).ticks(6).tickFormat(d3.format('.2f')));

        this.#g.select('.y-axis')
            .transition().duration(600)
            .call(d3.axisLeft(this.#yScale))
            .selectAll('text')
            .style('font-size', '11px');

        this.#svg.select('.bar-x-label')
            .text(METRIC_LABELS[this.#metric] || this.#metric);
    }

    #drawBars() {
        const self = this;
        const bw   = this.#yScale.bandwidth();

        const groups = this.#g.selectAll('.bar-group')
            .data(this.#data, d => d.Region);

        groups.exit()
            .transition().duration(400)
            .attr('opacity', 0).remove();

        const enter = groups.enter()
            .append('g')
            .attr('class', 'bar-group')
            .attr('transform', d => `translate(0,${this.#yScale(d.Region)})`);

        // Range whisker (min to max)
        enter.append('line').attr('class', 'whisker');

        // Tick marks at min and max
        enter.append('line').attr('class', 'whisker-tick whisker-min');
        enter.append('line').attr('class', 'whisker-tick whisker-max');

        // Main bar
        enter.append('rect')
            .attr('class', 'bar')
            .attr('height', bw)
            .attr('rx', 3)
            .attr('width', 0);

        // Value label
        enter.append('text')
            .attr('class', 'bar-val-label')
            .attr('dy', '0.35em')
            .attr('y', bw / 2)
            .style('font-size', '11px')
            .style('fill', '#e4e6eb');

        const merged = enter.merge(groups);

        merged.transition().duration(600)
            .attr('transform', d => `translate(0,${this.#yScale(d.Region)})`);

        // Whisker line
        merged.select('.whisker')
            .transition().duration(600)
            .attr('x1', d => this.#xScale(d.min))
            .attr('x2', d => this.#xScale(d.max))
            .attr('y1', bw / 2).attr('y2', bw / 2)
            .attr('stroke', '#8b93a7').attr('stroke-width', 1.5);

        merged.select('.whisker-min')
            .transition().duration(600)
            .attr('x1', d => this.#xScale(d.min)).attr('x2', d => this.#xScale(d.min))
            .attr('y1', bw * 0.25).attr('y2', bw * 0.75)
            .attr('stroke', '#8b93a7').attr('stroke-width', 1.5);

        merged.select('.whisker-max')
            .transition().duration(600)
            .attr('x1', d => this.#xScale(d.max)).attr('x2', d => this.#xScale(d.max))
            .attr('y1', bw * 0.25).attr('y2', bw * 0.75)
            .attr('stroke', '#8b93a7').attr('stroke-width', 1.5);

        // Bar rect
        merged.select('.bar')
            .on('mouseover', function(event, d) {
                self.#tooltip.style('opacity', 1).html(self.#tooltipHtml(d));
                d3.select(this).attr('filter', 'brightness(1.25)');
            })
            .on('mousemove', (event) => {
                const rect = this.#container.getBoundingClientRect();
                this.#tooltip
                    .style('left', (event.clientX - rect.left + 16) + 'px')
                    .style('top',  (event.clientY - rect.top  - 10) + 'px');
            })
            .on('mouseout', function() {
                self.#tooltip.style('opacity', 0);
                d3.select(this).attr('filter', null);
            })
            .on('click', (event, d) => {
                const isActive = this.#activeRegion === d.Region;
                if (isActive) {
                    this.clearHighlight();
                    if (this.#onRegionSelectCb) this.#onRegionSelectCb(null);
                } else {
                    this.highlight(d.Region);
                    if (this.#onRegionSelectCb) this.#onRegionSelectCb(d.Region);
                }
            })
            .transition().duration(600)
            .attr('width', d => this.#xScale(d.value))
            .attr('height', bw)
            .attr('fill', d => REGION_COLOURS[d.Region] || '#607d8b');

        // Value label
        merged.select('.bar-val-label')
            .transition().duration(600)
            .attr('x', d => this.#xScale(d.value) + 6)
            .attr('y', bw / 2)
            .text(d => `${d.value.toFixed(2)}  (${d.count})`);
    }

    #tooltipHtml(d) {
        return `
            <div class="tt-title">${d.Region}</div>
            <div class="tt-row"><span class="tt-label">Average</span><span>${d.value.toFixed(3)}</span></div>
            <div class="tt-row"><span class="tt-label">Range</span><span>${d.min.toFixed(2)} to ${d.max.toFixed(2)}</span></div>
            <div class="tt-row"><span class="tt-label">Countries</span><span>${d.count}</span></div>
        `;
    }
}

export default BarChart;
