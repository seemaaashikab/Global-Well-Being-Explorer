/**
 * DataManager.js
 * Centralised data loading, parsing, and querying for the Global Well-Being Explorer.
 *
 * This module is the single source of truth for all data in the application.
 * No chart component loads or parses CSV files directly. Instead, each chart
 * receives its data through the query methods exposed by this class.
 *
 * Key design decisions:
 *  - Region data only exists in the happiness CSV for 2015 and 2016.
 *    We build a country-to-region lookup from the 2015 rows and apply it
 *    to all years so that the scatter plot and map always have region colours.
 *  - The scatter chart uses gdp_per_capita_idx (a normalised 0-2 index from
 *    the World Happiness Report) as its x-axis because this field is available
 *    for all five years, whereas the raw World Bank GDP per capita has gaps.
 *  - A computed gdp_per_capita field (total GDP divided by population) is kept
 *    separately for tooltip display only.
 *  - getRegionAverages() accepts a metric parameter so the bar chart can
 *    switch between happiness, social support, freedom, etc.
 *
 * Exports:
 *  - DataManager (class)
 *  - REGION_COLOURS (constant object mapping region name to hex colour)
 */


/* ==============================================================
   Region Colour Palette
   Used across all charts (scatter legend, bar fills, etc.) to
   ensure every region has a consistent, recognisable colour.
   ============================================================== */
   
/** Consistent region colour palette used across all charts */
const REGION_COLOURS = {
    'Western Europe':                  '#4fc3f7',
    'North America':                   '#81c784',
    'Australia and New Zealand':       '#aed581',
    'Eastern Asia':                    '#fff176',
    'Latin America and Caribbean':     '#ffb74d',
    'Middle East and Northern Africa': '#ff8a65',
    'Southeastern Asia':               '#ce93d8',
    'Central and Eastern Europe':      '#90caf9',
    'Eastern Europe':                  '#80cbc4',
    'Southern Asia':                   '#f48fb1',
    'Sub-Saharan Africa':              '#ef5350'
};

class DataManager {

    /** @private CSV paths relative to index.html */
    #paths = {
        main:      'data/merged_wb_happiness_2015_2019.csv',
        full2015:  'data/merged_all_2015.csv',
        trends:    'data/wb_trends_1990_2023.csv',
        happiness: 'data/happiness_2015_2019.csv'
    };

    /** Parsed datasets (public for debugging) */
    main      = [];
    full2015  = [];
    trends    = [];
    happiness = [];

    /** Derived look-ups */
    regions   = [];
    countries = [];// Countries present in full2015 (radar source)
    years     = [];

    /** @private Country - Region lookup built from 2015 data */
    #regionLookup = new Map();

    /* Loading & Parsing */
    /*Load all CSV files concurrently.
     * Must be awaited before calling any query helper.
     * @returns {Promise<void>}
     */
    async load() {
        const [main, full2015, trends, happiness] = await Promise.all([
            d3.csv(this.#paths.main,      row => this.#parseMain(row)),
            d3.csv(this.#paths.full2015,  row => this.#parseFull2015(row)),
            d3.csv(this.#paths.trends,    row => this.#parseTrends(row)),
            d3.csv(this.#paths.happiness, row => this.#parseHappiness(row))
        ]);

        this.main      = main;
        this.full2015  = full2015;
        this.trends    = trends;
        this.happiness = happiness;

        // Build region lookup from 2015 data (most complete)
        this.main
            .filter(d => d.Year === 2015 && d.Region)
            .forEach(d => this.#regionLookup.set(d.Country, d.Region));

        // Back-fill Region on rows where it is missing (2017-2019)
        this.main.forEach(d => {
            if (!d.Region) d.Region = this.#regionLookup.get(d.Country) || null;
        });

        // Derived indices
        this.regions   = [...new Set(this.main.map(d => d.Region))].filter(Boolean).sort();
        this.countries = [...new Set(this.full2015.map(d => d.Country))].filter(Boolean).sort();
        this.years     = [...new Set(this.main.map(d => d.Year))].sort((a, b) => a - b);

        console.log(
            `[DataManager] Loaded - main:${main.length} full2015:${full2015.length}` +
            ` trends:${trends.length} happiness:${happiness.length}`
        );
    }

    /* Private row parsers */
    /* Parse a numeric CSV field, return null for blanks. */
    #n(v) { return (v === '' || v == null) ? null : +v; }

    #parseMain = (d) => {
        const gdpRaw = this.#n(d.GDP_current_US);
        const pop    = this.#n(d.population);
        return {
            Country:            d.Country,
            Year:               +d.Year,
            // World Bank indicators
            GDP_current_US:     gdpRaw,
            life_expectancy:    this.#n(d.life_expectancy_at_birth),
            population:         pop,
            CO2_emissions:      this.#n(d.CO2_emisions),
            electricity_access: this.#n(d['access_to_electricity%']),
            internet_users:     this.#n(d['individuals_using_internet%']),
            gini_index:         this.#n(d.gini_index),
            human_capital_idx:  this.#n(d.human_capital_index),
            // Happiness Report fields
            happiness:          this.#n(d['Happiness Score']),
            gdp_per_capita_idx: this.#n(d['GDP per Capita']),
            social_support:     this.#n(d['Social Support']),
            healthy_life_exp:   this.#n(d['Healthy Life Expectancy']),
            freedom:            this.#n(d.Freedom),
            generosity:         this.#n(d.Generosity),
            corruption:         this.#n(d['Perceptions of Corruption']),
            Region:             d.Region || null,
            // Computed real GDP/capita (WB), used for tooltip display
            gdp_per_capita:     (gdpRaw && pop) ? gdpRaw / pop : null
        };
    };

    #parseFull2015 = (d) => ({
        ...this.#parseMain(d),
        who_life_exp:      this.#n(d['Life expectancy ']),
        adult_mortality:   this.#n(d['Adult Mortality']),
        infant_deaths:     this.#n(d['infant deaths']),
        hepatitis_b:       this.#n(d['Hepatitis B']),
        measles:           this.#n(d['Measles ']),
        polio:             this.#n(d.Polio),
        total_expenditure: this.#n(d['Total expenditure']),
        diphtheria:        this.#n(d['Diphtheria ']),
        who_gdp:           this.#n(d.GDP),
        schooling:         this.#n(d.Schooling),
        dev_status:        d.Status
    });

    #parseTrends = (d) => ({
        Country:        d.Country,
        Year:           +d.Year,
        GDP_current_US: this.#n(d.GDP_current_US),
        life_expectancy:this.#n(d.life_expectancy_at_birth),
        population:     this.#n(d.population),
        CO2_emissions:  this.#n(d.CO2_emisions)
    });

    #parseHappiness = (d) => ({
        Country:            d.Country,
        Year:               +d.Year,
        happiness:          this.#n(d['Happiness Score']),
        gdp_per_capita_idx: this.#n(d['GDP per Capita']),
        social_support:     this.#n(d['Social Support']),
        healthy_life_exp:   this.#n(d['Healthy Life Expectancy']),
        freedom:            this.#n(d.Freedom),
        generosity:         this.#n(d.Generosity),
        corruption:         this.#n(d['Perceptions of Corruption']),
        Region:             d.Region || null
    });

    /* Public query helpers */

    /* Return main dataset rows for a single year.Region is always populated (back-filled from 2015 lookup).
     * @param {number} year
     * @returns {Array} */
    getByYear(year) {
        return this.main.filter(d => d.Year === year);
    }

    /** Return trend rows for specified countries.
     * @param {string[]} countries
     * @returns {Array}
     */
    getTrends(countries) {
        const set = new Set(countries);
        return this.trends.filter(d => set.has(d.Country));
    }

    /** Aggregate happiness data by region for a given year.
     * @param {number} year      - Must be 2015 or 2016 for meaningful regions.
     * @param {string} metric    - Field name to aggregate (default 'happiness').
     * @returns {Array<{Region, value, count, min, max}>}
     */
    getRegionAverages(year, metric = 'happiness') {
        // Use main dataset (region back-filled for all years)
        const yearData = this.main.filter(d => d.Year === year && d.Region && d[metric] != null);
        const grouped  = d3.group(yearData, d => d.Region);
        return Array.from(grouped, ([region, rows]) => ({
            Region:  region,
            value:   d3.mean(rows, d => d[metric]),
            count:   rows.length,
            min:     d3.min(rows,  d => d[metric]),
            max:     d3.max(rows,  d => d[metric])
        })).sort((a, b) => b.value - a.value);
    }

    /** Get the colour for a region, falls back to neutral grey.
     * @param {string} region
     * @returns {string} CSS colour
     */
    regionColour(region) {
        return REGION_COLOURS[region] || '#607d8b';
    }

    /** Get the merged 2015 profile row for a country (used by radar).
     * @param {string} country
     * @returns {Object|null}
     */
    getCountryProfile(country) {
        return this.full2015.find(d => d.Country === country) || null;
    }

    /** Compute normalised [0-1] radar axis values for a country (2015 data).
     * @param {string} country
     * @returns {Array<{axis: string, value: number, raw: number}>|null}
     */
    getRadarData(country) {
        const row = this.getCountryProfile(country);
        if (!row) return null;

        const axes = [
            { key: 'gdp_per_capita_idx', label: 'GDP / Capita' },
            { key: 'social_support',     label: 'Social Support' },
            { key: 'healthy_life_exp',   label: 'Health' },
            { key: 'freedom',            label: 'Freedom' },
            { key: 'generosity',         label: 'Generosity' },
            { key: 'corruption',         label: 'Low Corruption' }
        ];

        const maxVals = axes.map(({ key }) =>
            d3.max(this.full2015, d => d[key]) || 1
        );

        return axes.map(({ key, label }, i) => ({
            axis:  label,
            value: row[key] != null ? row[key] / maxVals[i] : 0,
            raw:   row[key]
        }));
    }
}

export { DataManager, REGION_COLOURS };