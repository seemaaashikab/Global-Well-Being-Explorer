/**
 * LineChart.js
 * Multi-series line chart for long-range World Bank trends (1990 to 2023).
 *
 * This chart is used in the "Trends Over Time" section. It plots one
 * smooth curve per selected country, showing how a chosen metric has
 * evolved over more than three decades.
 *
 * Features:
 *  - Multiple country lines with smooth curves (Cardinal spline, tension 0.4)
 *  - Switchable metric: GDP, life expectancy, population, CO2 emissions
 *  - Animated line drawing on first appear (stroke-dasharray/dashoffset trick)
 *  - Hover crosshair with a vertical rule snapping to the nearest year
 *  - Tooltip listing all visible countries and their values at the hovered year
 *  - Right-side inline legend showing country names at each line's endpoint
 *  - Click a line to dispatch the country name for cross-chart highlighting
 *  - Grid lines for readability
 *  - resize() recalculates dimensions when the browser window changes
 *
 * Data source: DataManager.getTrends(countries)
 * Returns: Array of {Country, Year, GDP_current_US, life_expectancy, population, CO2_emissions}
 */


import { REGION_COLOURS } from './DataManager.js';

class LineChart {
    #container;
    #svg;
    #g;
    #tooltip;

    #width;
    #height;
    #margin = { top: 30, right: 140, bottom: 60, left: 78 };

    #xScale;
    #yScale;
    #line;

    #data      = [];
    #metric    = 'GDP_current_US';
    #colourMap = {};
    #onSelectCb = null;

    /* Axis labels per metric key */
    static METRIC_LABELS = {
        GDP_current_US:  'GDP (current USD)',
        life_expectancy: 'Life Expectancy (years)',
        population:      'Population',
        CO2_emissions:   'CO2 Emissions (kt)'
    };

    static METRIC_FORMATS = {
        GDP_current_US:  v => '$' + d3.format('.2s')(v),
        life_expectancy: v => d3.format('.1f')(v) + ' yrs',
        population:      v => d3.format('.2s')(v),
        CO2_emissions:   v => d3.format('.2s')(v) + ' kt'
    };

    /** 
     * @param {string} containerSel
     * @param {string} tooltipSel */
    constructor(containerSel, tooltipSel) {
        this.#container = document.querySelector(containerSel);
        this.#tooltip   = d3.select(tooltipSel);
        this.#initSvg();
    }

    /*Public API*/

    /**
     * @param {Array}  data - Rows from DataManager.getTrends()
     * @param {string} metric - Column to plot on y-axis
     * @param {Object} colourMap - Country
     */
    render(data, metric, colourMap) {
        this.#data      = data;
        this.#metric    = metric || this.#metric;
        this.#colourMap = colourMap || {};
        this.#updateScales();
        this.#drawGrid();
        this.#drawAxes();
        this.#drawLines();
        this.#drawInlineLegend();
        this.#wireOverlay();
    }

    onCountrySelect(cb) { this.#onSelectCb = cb; }

    resize() {
        this.#initSvg();
        if (this.#data.length) this.render(this.#data, this.#metric, this.#colourMap);
    }

    /* Private */

    #initSvg() {
        const rect = this.#container.getBoundingClientRect();
        this.#width  = rect.width  - this.#margin.left - this.#margin.right;
        this.#height = Math.max(400, rect.height - 32) - this.#margin.top - this.#margin.bottom;

        d3.select(this.#container).select('svg').remove();

        this.#svg = d3.select(this.#container)
            .append('svg')
            .attr('width',  this.#width  + this.#margin.left + this.#margin.right)
            .attr('height', this.#height + this.#margin.top  + this.#margin.bottom);

        this.#g = this.#svg.append('g')
            .attr('transform', `translate(${this.#margin.left},${this.#margin.top})`);

        this.#g.append('g').attr('class', 'grid-y');
        this.#g.append('g').attr('class', 'x-axis').attr('transform', `translate(0,${this.#height})`);
        this.#g.append('g').attr('class', 'y-axis');
        this.#g.append('g').attr('class', 'lines-group');
        this.#g.append('g').attr('class', 'inline-legend');

        // Crosshair overlay
        this.#g.append('line').attr('class', 'crosshair')
            .attr('y1', 0).attr('y2', this.#height)
            .attr('stroke', '#4fc3f7').attr('stroke-width', 1)
            .attr('stroke-dasharray', '4,3').attr('opacity', 0);

        // Overlay rect for mouse events
        this.#g.append('rect').attr('class', 'overlay')
            .attr('width', this.#width).attr('height', this.#height)
            .attr('fill', 'none').attr('pointer-events', 'all');

        // Axis labels
        this.#svg.append('text').attr('class', 'axis-label')
            .attr('text-anchor', 'middle')
            .attr('x', this.#margin.left + this.#width / 2)
            .attr('y', this.#height + this.#margin.top + 50)
            .text('Year');

        this.#svg.append('text').attr('class', 'axis-label line-y-label')
            .attr('text-anchor', 'middle')
            .attr('transform', 'rotate(-90)')
            .attr('x', -(this.#margin.top + this.#height / 2))
            .attr('y', 16);
    }

    #updateScales() {
        const yExt = d3.extent(
            this.#data.map(d => d[this.#metric]).filter(v => v != null)
        );

        this.#xScale = d3.scaleLinear()
            .domain(d3.extent(this.#data, d => d.Year))
            .range([0, this.#width]);

        this.#yScale = d3.scaleLinear()
            .domain([Math.min(0, yExt[0]), yExt[1] * 1.05])
            .nice()
            .range([this.#height, 0]);

        this.#line = d3.line()
            .defined(d => d[this.#metric] != null)
            .x(d => this.#xScale(d.Year))
            .y(d => this.#yScale(d[this.#metric]))
            .curve(d3.curveCardinal.tension(0.4));

        this.#svg.select('.line-y-label')
            .text(LineChart.METRIC_LABELS[this.#metric] || this.#metric);
    }

    #drawGrid() {
        this.#g.select('.grid-y')
            .call(
                d3.axisLeft(this.#yScale).ticks(6)
                    .tickSize(-this.#width).tickFormat('')
            )
            .call(g => g.select('.domain').remove())
            .selectAll('line')
            .attr('stroke', '#2d3548').attr('stroke-dasharray', '3,3');
    }

    #drawAxes() {
        this.#g.select('.x-axis')
            .transition().duration(600)
            .call(d3.axisBottom(this.#xScale).tickFormat(d3.format('d')).ticks(8));

        const fmt = LineChart.METRIC_FORMATS[this.#metric] || d3.format('.2s');
        this.#g.select('.y-axis')
            .transition().duration(600)
            .call(d3.axisLeft(this.#yScale).ticks(6).tickFormat(fmt));
    }

    #drawLines() {
        const self    = this;
        const grouped = d3.group(this.#data, d => d.Country);
        const lineData = Array.from(grouped, ([country, rows]) => ({
            country,
            values: rows.sort((a, b) => a.Year - b.Year)
        }));

        const paths = this.#g.select('.lines-group')
            .selectAll('.trend-line')
            .data(lineData, d => d.country);

        paths.exit().transition().duration(400).attr('opacity', 0).remove();

        const enter = paths.enter()
            .append('path')
            .attr('class', 'trend-line')
            .attr('fill', 'none')
            .attr('stroke-width', 2.5)
            .attr('opacity', 0);

        enter.merge(paths)
            .on('mouseover', function(event, d) {
                d3.select(this).raise().attr('stroke-width', 4).attr('opacity', 1);
            })
            .on('mouseout', function() {
                d3.select(this).attr('stroke-width', 2.5).attr('opacity', 0.9);
            })
            .on('click', (event, d) => {
                if (this.#onSelectCb) this.#onSelectCb(d.country);
            })
            .transition().duration(800)
            .attr('d', d => this.#line(d.values))
            .attr('stroke', d => this.#colourMap[d.country] || '#4fc3f7')
            .attr('opacity', 0.9);

        // Animate new lines with dash-draw
        enter.each(function() {
            const len = this.getTotalLength ? this.getTotalLength() : 0;
            if (len > 0) {
                d3.select(this)
                    .attr('stroke-dasharray', len)
                    .attr('stroke-dashoffset', len)
                    .transition().duration(1400).ease(d3.easeQuadOut)
                    .attr('stroke-dashoffset', 0).attr('opacity', 0.9);
            }
        });
    }

    #drawInlineLegend() {
        const grouped = d3.group(this.#data, d => d.Country);
        const legend  = this.#g.select('.inline-legend');
        legend.selectAll('*').remove();

        grouped.forEach((rows, country) => {
            const sorted = [...rows].sort((a, b) => a.Year - b.Year);
            const last = sorted[sorted.length - 1];
            if (!last || last[this.#metric] == null) return;

            const g = legend.append('g');
            g.append('line')
                .attr('x1', this.#width + 6).attr('x2', this.#width + 18)
                .attr('y1', this.#yScale(last[this.#metric]))
                .attr('y2', this.#yScale(last[this.#metric]))
                .attr('stroke', this.#colourMap[country] || '#4fc3f7')
                .attr('stroke-width', 2);

            g.append('text')
                .attr('x', this.#width + 22)
                .attr('y', this.#yScale(last[this.#metric]))
                .attr('dy', '0.35em')
                .style('font-size', '10px')
                .style('fill', this.#colourMap[country] || '#4fc3f7')
                .text(country);
        });
    }

    #wireOverlay() {
        const self = this;
        const grouped = d3.group(this.#data, d => d.Country);
        const fmt = LineChart.METRIC_FORMATS[this.#metric] || d3.format('.2s');

        this.#g.select('.overlay')
            .on('mousemove', function(event) {
                const [mx] = d3.pointer(event);
                const year  = Math.round(self.#xScale.invert(mx));
                const crossX = self.#xScale(year);

                self.#g.select('.crosshair')
                    .attr('x1', crossX).attr('x2', crossX)
                    .attr('opacity', 1);

                // Build tooltip with all countries at this year
                const rows = [];
                grouped.forEach((vals, country) => {
                    const row = vals.find(d => d.Year === year);
                    if (row && row[self.#metric] != null) {
                        rows.push({ country, val: row[self.#metric] });
                    }
                });
                rows.sort((a, b) => b.val - a.val);

                if (rows.length) {
                    const rect = self.#container.getBoundingClientRect();
                    self.#tooltip.style('opacity', 1).html(`
                        <div class="tt-title">${year}</div>
                        ${rows.map(r => `
                            <div class="tt-row">
                                <span class="tt-label" style="color:${self.#colourMap[r.country] || '#4fc3f7'}">${r.country}</span>
                                <span>${fmt(r.val)}</span>
                            </div>`).join('')}
                    `)
                    .style('left', (event.clientX - rect.left + 16) + 'px')
                    .style('top',  (event.clientY - rect.top  - 10) + 'px');
                }
            })
            .on('mouseout', () => {
                this.#g.select('.crosshair').attr('opacity', 0);
                this.#tooltip.style('opacity', 0);
            });
    }
}

export default LineChart;


