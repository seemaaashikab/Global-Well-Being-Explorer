/**
 * ScatterChart.js
 * GDP per Capita Index vs Happiness Score scatter plot.
 *
 * This chart is the centrepiece of the "Wealth and Happiness" section.
 * It plots every country as a circle with:
 *  - x-axis: gdp_per_capita_idx (normalised 0-2 happiness-report GDP index)
 *  - y-axis: happiness score
 *  - colour: region (using the shared REGION_COLOURS palette)
 *  - size:   population (square-root scale so area is proportional)
 *
 * Scale choice: LINEAR (not logarithmic). The GDP index is already normalised
 * to a 0-2 range and has a fairly uniform distribution, so a linear scale
 * spreads countries more evenly and makes year-to-year movement clearly visible.
 *
 * Features:
 *  - Dashed smoothed trend line using a moving-average approach
 *  - Grid lines for readability
 *  - Hover tooltip showing country details
 *  - Click fires the onCountrySelect callback for cross-chart interaction
 *  - Named D3 transitions ('render' and 'highlight') so that position
 *    animations and opacity animations can run simultaneously without
 *    one interrupting the other
 *  - highlight() / clearHighlight() for cross-chart country selection
 *  - resize() recalculates dimensions when the browser window changes
 */

import { REGION_COLOURS } from './DataManager.js';

class ScatterChart {

    #container;     // DOM element for the chart container div
    #svg;           // D3 selection of the root <svg> element
    #g;             // D3 selection of the main <g> group (offset by margins)
    #tooltip;       // D3 selection of the tooltip div

    #width;         // Inner chart width (excluding margins)
    #height;        // Inner chart height (excluding margins)
    #margin = { top: 30, right: 40, bottom: 60, left: 60 };

    #xScale;        // D3 linear scale for GDP index (x-axis)
    #yScale;        // D3 linear scale for happiness score (y-axis)
    #rScale;        // D3 square-root scale for population-based circle radius

    #data = [];             // Currently rendered data array
    #selectedCountry = null; // Name of the currently highlighted country, or null
    #onSelectCb = null;      // Callback function registered via onCountrySelect()


    /**
     * @param {string} containerSel //CSS selector for the chart div
     * @param {string} tooltipSel //CSS selector for the tooltip div
     */
    constructor(containerSel, tooltipSel) {
        this.#container = document.querySelector(containerSel);
        this.#tooltip   = d3.select(tooltipSel);
        this.#initSvg();
    }

    /* ==============================================================
       Public API
       ============================================================== */

    /**
     * Render or update the chart with new data.
     * Filters out rows that are missing GDP index or happiness values,
     * then updates scales, grid, trend line, axes, and data points.
     * All dots animate to their new positions, sizes, and colours.
     *
     * @param {Array<Object>} data - Rows from DataManager.getByYear(), each with
     *                               at least: Country, Year, gdp_per_capita_idx,
     *                               happiness, population, Region
     */
    render(data) {
        this.#data = data.filter(d => d.gdp_per_capita_idx != null && d.happiness != null);
        this.#updateScales();
        this.#drawGrid();
        this.#drawTrendLine();
        this.#drawAxes();
        this.#drawPoints();
    }

    /* Dim all dots except the named country */
    highlight(country) {
        this.#selectedCountry = country;
        this.#g.selectAll('.dot')
            .transition('highlight').duration(300)
            .attr('opacity', d => (!country || d.Country === country) ? 0.9 : 0.1)
            .attr('stroke-width', d => d.Country === country ? 2.5 : 0.5)
            .attr('stroke', d => d.Country === country ? '#fff' : '#111');
    }

    /* Restore all dots to full opacity */
    clearHighlight() {
        this.#selectedCountry = null;
        this.#g.selectAll('.dot')
            .transition('highlight').duration(300)
            .attr('opacity', 0.82)
            .attr('stroke-width', 0.5)
            .attr('stroke', '#111');
    }

    /* Register callback for dot clicks */
    onCountrySelect(cb) { this.#onSelectCb = cb; }

    /** Recompute SVG dimensions and re-render. */
    resize() {
        this.#initSvg();
        if (this.#data.length) this.render(this.#data);
    }

    /* ==============================================================
       Private Methods
       ============================================================== */

    /**
     * Initialise (or reinitialise) the SVG element and all fixed layers.
     * Removes any existing SVG, reads the container dimensions, creates
     * a new SVG with the correct width/height, and appends placeholder
     * groups for grid, trend line, axes, and dots.
     * @private
     */

    #initSvg() {
        const rect = this.#container.getBoundingClientRect();
        this.#width  = rect.width  - this.#margin.left - this.#margin.right;
        this.#height = Math.max(400, rect.height - 32) - this.#margin.top - this.#margin.bottom;

        d3.select(this.#container).select('svg').remove();

        this.#svg = d3.select(this.#container)
            .append('svg')
            .attr('width',  this.#width  + this.#margin.left + this.#margin.right)
            .attr('height', this.#height + this.#margin.top  + this.#margin.bottom);

        this.#g = this.#svg.append('g')
            .attr('transform', `translate(${this.#margin.left},${this.#margin.top})`);

        // Layer order
        this.#g.append('g').attr('class', 'grid-y');
        this.#g.append('g').attr('class', 'grid-x');
        this.#g.append('path').attr('class', 'trend-line');
        this.#g.append('g').attr('class', 'x-axis').attr('transform', `translate(0,${this.#height})`);
        this.#g.append('g').attr('class', 'y-axis');
        this.#g.append('g').attr('class', 'dots');

        // Axis labels
        this.#svg.append('text').attr('class', 'axis-label')
            .attr('text-anchor', 'middle')
            .attr('x', this.#margin.left + this.#width / 2)
            .attr('y', this.#height + this.#margin.top + 50)
            .text('GDP per Capita Index');

        this.#svg.append('text').attr('class', 'axis-label')
            .attr('text-anchor', 'middle')
            .attr('transform', 'rotate(-90)')
            .attr('x', -(this.#margin.top + this.#height / 2))
            .attr('y', 16)
            .text('Happiness Score');
    }

    #updateScales() {
        const xMax = d3.max(this.#data, d => d.gdp_per_capita_idx) || 2;
        const yExt = d3.extent(this.#data, d => d.happiness);
        const pExt = d3.extent(this.#data, d => d.population);

        // Linear scale 
        this.#xScale = d3.scaleLinear()
            .domain([0, xMax * 1.06])
            .range([0, this.#width]);

        this.#yScale = d3.scaleLinear()
            .domain([Math.max(0, yExt[0] - 0.5), yExt[1] + 0.3])
            .range([this.#height, 0]);

        this.#rScale = d3.scaleSqrt()
            .domain([0, pExt[1] || 1e9])
            .range([3, 28]);
    }

    #drawGrid() {
        this.#g.select('.grid-y')
            .call(
                d3.axisLeft(this.#yScale).ticks(6)
                    .tickSize(-this.#width).tickFormat('')
            )
            .call(g => g.select('.domain').remove())
            .selectAll('line')
            .attr('stroke', '#2a3349').attr('stroke-dasharray', '3,4');

        this.#g.select('.grid-x')
            .call(
                d3.axisBottom(this.#xScale).ticks(8)
                    .tickSize(this.#height).tickFormat('')
            )
            .call(g => g.select('.domain').remove())
            .selectAll('line')
            .attr('stroke', '#2a3349').attr('stroke-dasharray', '3,4');
    }

    #drawTrendLine() {
        // Smooth trend 
        const sorted = [...this.#data].sort((a, b) => a.gdp_per_capita_idx - b.gdp_per_capita_idx);
        const w = Math.max(4, Math.floor(sorted.length * 0.12));

        const smoothed = sorted.map((d, i) => {
            const from  = Math.max(0, i - w);
            const to    = Math.min(sorted.length - 1, i + w);
            const slice = sorted.slice(from, to + 1);
            return {
                x: d.gdp_per_capita_idx,
                y: d3.mean(slice, s => s.happiness)
            };
        }).filter(p => p.y != null);

        const lineGen = d3.line()
            .x(p => this.#xScale(p.x))
            .y(p => this.#yScale(p.y))
            .curve(d3.curveBasis);

        this.#g.select('.trend-line')
            .datum(smoothed)
            .transition().duration(700)
            .attr('d', lineGen)
            .attr('fill', 'none')
            .attr('stroke', '#f59e0b')
            .attr('stroke-width', 2)
            .attr('stroke-dasharray', '7,4')
            .attr('opacity', 0.65);
    }

    #drawAxes() {
        this.#g.select('.x-axis')
            .transition().duration(600)
            .call(d3.axisBottom(this.#xScale).ticks(8).tickFormat(d3.format('.2f')));

        this.#g.select('.y-axis')
            .transition().duration(600)
            .call(d3.axisLeft(this.#yScale).ticks(6));
    }

    #drawPoints() {
        const self  = this;
        const dotsG = this.#g.select('.dots');

        const dots = dotsG.selectAll('.dot')
            .data(this.#data, d => d.Country);

        // EXIT - shrink and remove
        dots.exit()
            .transition('render').duration(400)
            .attr('r', 0).attr('opacity', 0)
            .remove();

        // ENTER - start at computed position with r=0
        const enter = dots.enter()
            .append('circle')
            .attr('class', 'dot')
            .attr('cx', d => this.#xScale(d.gdp_per_capita_idx))
            .attr('cy', d => this.#yScale(d.happiness))
            .attr('r', 0)
            .attr('fill', d => REGION_COLOURS[d.Region] || '#607d8b')
            .attr('stroke', '#111')
            .attr('stroke-width', 0.5)
            .attr('opacity', 0);

        // MERGE enter and update, animate ALL properties so year changes are visible
        enter.merge(dots)
            .on('mouseover', function(event, d) {
                d3.select(this).raise()
                    .attr('stroke', '#fff').attr('stroke-width', 2);
                self.#showTooltip(event, d);
            })
            .on('mousemove', (event) => {
                const rect = this.#container.getBoundingClientRect();
                this.#tooltip
                    .style('left', (event.clientX - rect.left + 16) + 'px')
                    .style('top',  (event.clientY - rect.top  - 10) + 'px');
            })
            .on('mouseout', function() {
                d3.select(this).attr('stroke', '#111').attr('stroke-width', 0.5);
                self.#tooltip.style('opacity', 0);
            })
            .on('click', (event, d) => {
                if (this.#onSelectCb) this.#onSelectCb(d.Country);
            })
            // Transition ALL visual properties so position/size/colour all animate
            .transition('render').duration(750).ease(d3.easeCubicInOut)
            .attr('cx', d => this.#xScale(d.gdp_per_capita_idx))
            .attr('cy', d => this.#yScale(d.happiness))
            .attr('r',  d => this.#rScale(d.population || 5e6))
            .attr('fill', d => REGION_COLOURS[d.Region] || '#607d8b')
            .attr('opacity', 0.82);
    }

    #showTooltip(event, d) {
        const fmtPop = d3.format(',.0f');
        const fmtMon = d3.format('$,.0f');
        this.#tooltip.style('opacity', 1).html(`
            <div class="tt-title">${d.Country}</div>
            <div class="tt-row"><span class="tt-label">Year</span><span>${d.Year}</span></div>
            <div class="tt-row"><span class="tt-label">Region</span><span>${d.Region || 'N/A'}</span></div>
            <div class="tt-row"><span class="tt-label">Happiness</span><span>${d.happiness.toFixed(2)}</span></div>
            <div class="tt-row"><span class="tt-label">GDP Index</span><span>${d.gdp_per_capita_idx.toFixed(3)}</span></div>
            ${d.gdp_per_capita != null
                ? `<div class="tt-row"><span class="tt-label">GDP/capita</span><span>${fmtMon(d.gdp_per_capita)}</span></div>`
                : ''}
            ${d.population != null
                ? `<div class="tt-row"><span class="tt-label">Population</span><span>${fmtPop(d.population)}</span></div>`
                : ''}
            ${d.life_expectancy != null
                ? `<div class="tt-row"><span class="tt-label">Life Exp.</span><span>${d.life_expectancy.toFixed(1)} yrs</span></div>`
                : ''}
        `);
    }
}

export default ScatterChart;