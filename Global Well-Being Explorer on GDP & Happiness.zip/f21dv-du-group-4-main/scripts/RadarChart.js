/**
 * RadarChart.js
 * Multi-dimensional country well-being profile (spider/radar chart).
 *
 * This is the project's creative visualisation, going beyond the chart types
 * shown in lectures and labs. It is used in the "Country Profile" section.
 *
 * The chart compares up to three countries simultaneously across six
 * well-being dimensions. Each country is drawn as a filled polygon
 * whose vertices sit on spoke axes radiating from the centre.
 *
 * Axes (6 total):
 *  - GDP / Capita (from the World Happiness Report index)
 *  - Social Support
 *  - Health (healthy life expectancy)
 *  - Freedom (freedom to make life choices)
 *  - Generosity
 *  - Low Corruption (perceptions of corruption, higher = less corrupt)
 *
 * All values are normalised to a 0-1 range (divided by the dataset maximum)
 * so that different indicators can be compared on the same scale.
 *
 * Features:
 *  - Up to 3 overlaid country polygons with distinct colours (blue, orange, green)
 *  - Semi-transparent filled polygons with contrasting stroke outline
 *  - Vertex dots at each axis point (hoverable for exact value)
 *  - 5 concentric ring grid lines with percentage labels (20%, 40%, ..., 100%)
 *  - Spoke lines from centre to each axis with end-cap dots
 *  - Axis label hover shows a floating callout with raw values for all countries
 *  - Animated transitions when countries are added, removed, or changed
 *  - Colour legend below the chart showing which colour is which country
 *  - Auto-populated from clicks in the scatter, map, and line charts
 *  - resize() recalculates dimensions when the browser window changes
 *
 * Data source: DataManager.getRadarData(country)
 * Returns: Array of {axis, value (normalised 0-1), raw (original value)}
 */

import { REGION_COLOURS } from './DataManager.js';

class RadarChart {

    #container;
    #svg;
    #g;
    #width;
    #height;
    #radius;
    #margin = 70;

    #angleSlice;
    #rScale;
    #axisLabels = [];
    #datasets   = [];

    /** Colour palette formax 3 countries */
    static PALETTE = ['#4fc3f7', '#ff9800', '#66bb6a'];

    /** @param {string} containerSel */
    constructor(containerSel) {
        this.#container = document.querySelector(containerSel);
        this.#initSvg();
    }

    /* ==============================================================
       Public API
       ============================================================== */

    /**
     * Render or update the radar chart with new country datasets.
     * If no valid datasets are provided, all existing polygons are removed.
     *
     * @param {Array<Object>} datasets - Array of up to 3 objects, each with:
     *   - country {string}: the country name
     *   - values {Array<{axis, value, raw}>}: normalised axis values from DataManager.getRadarData()
     */
    render(datasets) {
        this.#datasets   = datasets.filter(d => d && d.values);
        if (!this.#datasets.length) {
            this.#g.selectAll('.radar-area').remove();
            return;
        }

        this.#axisLabels = this.#datasets[0].values.map(d => d.axis);
        this.#angleSlice = (2 * Math.PI) / this.#axisLabels.length;
        this.#rScale     = d3.scaleLinear().domain([0, 1]).range([0, this.#radius]);

        this.#drawRings();
        this.#drawAxes();
        this.#drawPolygons();
        this.#drawLegend();
    }

    resize() {
        this.#initSvg();
        if (this.#datasets.length) this.render(this.#datasets);
    }

    /* ==============================================================
       Private Methods
       ============================================================== */

    /**
     * Initialise or reinitialise the SVG element.
     * The main group is translated to the centre of the SVG so that
     * all radial calculations can use (0,0) as the origin.
     * @private
     */

    #initSvg() {
        const rect = this.#container.getBoundingClientRect();
        this.#width  = rect.width;
        this.#height = Math.max(440, rect.height - 32);
        this.#radius = Math.min(this.#width, this.#height) / 2 - this.#margin;

        d3.select(this.#container).select('svg').remove();

        this.#svg = d3.select(this.#container)
            .append('svg')
            .attr('width', this.#width)
            .attr('height', this.#height);

        this.#g = this.#svg.append('g')
            .attr('transform', `translate(${this.#width / 2},${this.#height / 2})`);
    }

    #drawRings() {
        this.#g.selectAll('.ring-circle').remove();
        this.#g.selectAll('.ring-label').remove();

        const levels = 5;
        for (let i = 1; i <= levels; i++) {
            const r = (this.#radius / levels) * i;

            this.#g.append('circle')
                .attr('class', 'ring-circle')
                .attr('r', r)
                .attr('fill', 'none')
                .attr('stroke', '#2d3548')
                .attr('stroke-dasharray', i < levels ? '3,4' : 'none')
                .attr('stroke-width', i === levels ? 1.5 : 1);

            // Percentage label at 12 o'clock
            this.#g.append('text')
                .attr('class', 'ring-label')
                .attr('x', 4)
                .attr('y', -r)
                .style('font-size', '9px')
                .style('fill', '#4a5570')
                .text(`${(i / levels * 100).toFixed(0)}%`);
        }
    }

    #drawAxes() {
        this.#g.selectAll('.radar-axis-line').remove();
        this.#g.selectAll('.radar-axis-text').remove();

        const self = this;

        this.#axisLabels.forEach((label, i) => {
            const angle = this.#angleSlice * i - Math.PI / 2;
            const xe = this.#radius * Math.cos(angle);
            const ye = this.#radius * Math.sin(angle);

            // Spoke line
            this.#g.append('line')
                .attr('class', 'radar-axis-line')
                .attr('x1', 0).attr('y1', 0)
                .attr('x2', xe).attr('y2', ye)
                .attr('stroke', '#2d3548').attr('stroke-width', 1);

            // End-cap dot
            this.#g.append('circle')
                .attr('class', 'radar-axis-line')
                .attr('cx', xe).attr('cy', ye)
                .attr('r', 3)
                .attr('fill', '#2d3548');

            // Label
            const lx = (this.#radius + 24) * Math.cos(angle);
            const ly = (this.#radius + 24) * Math.sin(angle);
            const anchor = lx > 5 ? 'start' : lx < -5 ? 'end' : 'middle';

            const axText = this.#g.append('text')
                .attr('class', 'radar-axis-text')
                .attr('x', lx).attr('y', ly)
                .attr('text-anchor', anchor)
                .attr('dy', '0.35em')
                .style('font-size', '12px')
                .style('fill', '#8b93a7')
                .style('cursor', 'pointer')
                .text(label);

            // Hover axis label to show values for all selected countries
            axText
                .on('mouseover', function(event) {
                    d3.select(this).style('fill', '#e4e6eb').style('font-weight', '600');

                    const lines = self.#datasets.map((ds, idx) => {
                        const pt = ds.values[i];
                        return `<div class="tt-row">
                            <span class="tt-label" style="color:${RadarChart.PALETTE[idx]}">${ds.country}</span>
                            <span>${pt ? pt.value.toFixed(3) : 'N/A'}${pt && pt.raw != null ? ` (raw: ${pt.raw.toFixed(3)})` : ''}</span>
                        </div>`;
                    }).join('');

                    const rect = self.#container.getBoundingClientRect();
                    // Show info in a fixed tooltip we build inline
                    self.#g.select('.axis-callout').remove();
                    const cx = lx + self.#width / 2;
                    const cy = ly + self.#height / 2;

                    // Use a foreignObject or just a floating div
                    const callout = document.createElement('div');
                    callout.className = 'radar-callout';
                    callout.innerHTML = `<strong>${label}</strong>${lines}`;
                    callout.style.left = (cx + 10) + 'px';
                    callout.style.top  = (cy - 10) + 'px';
                    self.#container.style.position = 'relative';
                    self.#container.appendChild(callout);
                })
                .on('mouseout', function() {
                    d3.select(this).style('fill', '#8b93a7').style('font-weight', 'normal');
                    self.#container.querySelectorAll('.radar-callout').forEach(el => el.remove());
                });
        });
    }

    #drawPolygons() {
        const self = this;

        const radarLine = d3.lineRadial()
            .radius(d => this.#rScale(d.value))
            .angle((d, i) => i * this.#angleSlice)
            .curve(d3.curveLinearClosed);

        const polys = this.#g.selectAll('.radar-area')
            .data(this.#datasets, d => d.country);

        polys.exit().transition().duration(400).attr('opacity', 0).remove();

        const enter = polys.enter().append('g').attr('class', 'radar-area');

        // Filled area
        enter.append('path').attr('class', 'radar-fill');
        // Stroke outline
        enter.append('path').attr('class', 'radar-stroke');

        const merged = enter.merge(polys);

        merged.select('.radar-fill')
            .transition().duration(800)
            .attr('d', d => radarLine(d.values))
            .attr('fill', (d, i) => RadarChart.PALETTE[i % 3])
            .attr('fill-opacity', 0.15);

        merged.select('.radar-stroke')
            .transition().duration(800)
            .attr('d', d => radarLine(d.values))
            .attr('stroke', (d, i) => RadarChart.PALETTE[i % 3])
            .attr('stroke-width', 2.5)
            .attr('fill', 'none')
            .attr('opacity', 0.9);

        // Vertex dots
        merged.each(function(dataset, idx) {
            const colour = RadarChart.PALETTE[idx % 3];

            const dots = d3.select(this).selectAll('.radar-dot')
                .data(dataset.values);

            dots.enter().append('circle')
                .attr('class', 'radar-dot')
                .attr('r', 0)
                .attr('fill', colour)
                .attr('stroke', '#0f1419')
                .attr('stroke-width', 1.5)
                .merge(dots)
                .on('mouseover', function(event, d) {
                    d3.select(this).attr('r', 8);
                    // Show value in a small tooltip via container
                    const callout = document.createElement('div');
                    callout.className = 'radar-callout';
                    callout.innerHTML = `<strong>${d.axis}</strong><div class="tt-row"><span class="tt-label">${dataset.country}</span><span>${d.value.toFixed(3)}</span></div>`;
                    const svgRect = self.#container.querySelector('svg').getBoundingClientRect();
                    const conRect = self.#container.getBoundingClientRect();
                    callout.style.left = (event.clientX - conRect.left + 12) + 'px';
                    callout.style.top  = (event.clientY - conRect.top  - 10) + 'px';
                    self.#container.style.position = 'relative';
                    self.#container.appendChild(callout);
                })
                .on('mouseout', function() {
                    d3.select(this).transition().duration(200).attr('r', 5);
                    self.#container.querySelectorAll('.radar-callout').forEach(el => el.remove());
                })
                .transition().duration(800)
                .attr('cx', (d, i) => self.#rScale(d.value) * Math.cos(self.#angleSlice * i - Math.PI / 2))
                .attr('cy', (d, i) => self.#rScale(d.value) * Math.sin(self.#angleSlice * i - Math.PI / 2))
                .attr('r', 5);

            dots.exit().transition().duration(300).attr('r', 0).remove();
        });
    }

    #drawLegend() {
        const el = document.getElementById('radar-legend');
        if (!el) return;
        el.innerHTML = this.#datasets.map((d, i) => `
            <span class="legend-item">
                <span class="legend-swatch" style="background:${RadarChart.PALETTE[i % 3]};"></span>
                ${d.country}
            </span>
        `).join('');
    }
}

export default RadarChart;