# `scripts/` — JavaScript Modules

All application logic is split into ES6 modules. Each chart is a self-contained class with a consistent interface. `main.js` orchestrates them by holding shared application state and wiring all interactions.

---

## Module Overview

| File | Class | Responsibility |
|---|---|---|
| `DataManager.js` | `DataManager` | Load, parse, and query all CSV data |
| `ScatterChart.js` | `ScatterChart` | GDP per Capita vs Happiness scatter plot |
| `ChoroplethMap.js` | `ChoroplethMap` | Interactive world choropleth map |
| `BarChart.js` | `BarChart` | Regional happiness horizontal bar chart |
| `LineChart.js` | `LineChart` | Multi-country long-range trend line chart |
| `RadarChart.js` | `RadarChart` | Multi-axis country well-being radar/spider chart |
| `main.js` | *(no class)* | App bootstrap, state management, event wiring |

---

## `DataManager.js`

**Exports:** `DataManager` (class), `REGION_COLOURS` (object)

The single source of truth for all data in the application. No chart loads its own data — they all receive it through `DataManager`.

### Key Responsibilities
- Loads all four CSV files concurrently with `Promise.all`
- Parses raw CSV strings into typed JavaScript objects (numbers become `number`, blanks become `null`)
- Renames raw CSV headers to clean JS property names (e.g., `"Happiness Score"` → `happiness`)
- Back-fills missing `Region` values using a 2015 lookup map
- Exposes query helpers so charts never filter or aggregate data themselves

### Public API

| Method / Property | Returns | Description |
|---|---|---|
| `await dm.load()` | `Promise<void>` | Must be called before any query. Loads all four CSVs. |
| `dm.getByYear(year)` | `Array` | All rows from `main` dataset matching `year` (2015–2019) |
| `dm.getTrends(countries)` | `Array` | Trend rows for the specified array of country names |
| `dm.getRegionAverages(year, metric)` | `Array<{Region, value, count, min, max}>` | Aggregated regional stats for a given year and metric |
| `dm.getCountryProfile(country)` | `Object \| null` | Single 2015 full-profile row for a country (radar source) |
| `dm.getRadarData(country)` | `Array<{axis, value, raw}> \| null` | Normalised [0–1] radar axis values for a country |
| `dm.regionColour(region)` | `string` | CSS colour for a region from `REGION_COLOURS` |
| `dm.regions` | `string[]` | Sorted unique region names |
| `dm.countries` | `string[]` | Sorted unique country names (from `full2015`) |
| `dm.years` | `number[]` | Sorted unique years in the main dataset |

### `REGION_COLOURS`
A constant object mapping region name → CSS hex colour, shared with all charts for visual consistency.

---

## `ScatterChart.js`

**Exports:** `ScatterChart` (default)  
**Data source:** `dm.getByYear(year)`  
**Section:** "Wealth & Happiness"

Renders a log-scale scatter plot of GDP per Capita (x) vs Happiness Score (y). Points are coloured by region and sized by population.

### Features
- Log-scale x-axis for GDP (handles the wide dollar range)
- Population-proportional circle radius
- Hover tooltip with country name, GDP, happiness, and region
- Click-to-select dispatches country to `main.js` for cross-chart updates
- Animated transitions when data changes (year switch)
- Brush-to-zoom on x-axis
- `highlight(country)` — dims all other points, enlarges selected
- `clearHighlight()` — restores all points to normal
- `resize()` — redraws to fit new container width

### Key Parameters
- `containerSel` — CSS selector for the SVG container element
- `tooltipSel` — CSS selector for the tooltip `<div>`

### Callback
```javascript
scatter.onCountrySelect(country => { /* country is a string */ });
```

---

## `ChoroplethMap.js`

**Exports:** `ChoroplethMap` (default)  
**Data source:** `dm.getByYear(year)` + world TopoJSON (fetched at init)  
**Section:** "World Map"

Renders a Natural Earth projection world map coloured by a selected metric. Supports zoom, pan, metric switching, and bidirectional country highlighting with the scatter plot.

### Features
- Natural Earth projection via D3 + TopoJSON
- Sequential colour scales (one per metric: `YlGnBu`, `Viridis`, `RdYlGn`, `Purples`)
- Fixed colour domain per metric (prevents scale from shifting year-to-year)
- Zoom and pan (D3 zoom behaviour)
- Hover tooltip with country name and metric value
- Click → highlight country across all charts
- Legend showing colour gradient and domain endpoints
- `loadGeo()` — async; must be awaited alongside `dm.load()` before rendering
- `highlight(country)` / `clearHighlight()` / `resize()`

### Supported Metrics
| Key | Label | Scale |
|---|---|---|
| `happiness` | Happiness Score | YlGnBu, domain [2.5, 8] |
| `gdp_per_capita` | GDP per Capita | Viridis, domain [200, 80000] |
| `life_expectancy` | Life Expectancy | RdYlGn, domain [45, 85] |
| `internet_users` | Internet Access % | Purples, domain [0, 100] |

### Callback
```javascript
choropleth.onCountrySelect(country => { /* country is a string */ });
```

---

## `BarChart.js`

**Exports:** `BarChart` (default)  
**Data source:** `dm.getRegionAverages(year, metric)`  
**Section:** "Regional View"

Horizontal bar chart comparing average happiness (or another metric) across world regions, sorted by value descending.

### Features
- Horizontal layout (long region labels fit naturally)
- Bars coloured by `REGION_COLOURS` for consistency with scatter
- Metric switcher (happiness, GDP index, social support, life expectancy, freedom)
- Click a bar → dispatches region to main.js, which filters scatter
- Click selected bar again → deselects (clears filter)
- Range labels on bars showing min/max per region
- Animated transitions on data or metric change
- `highlight(region)` / `clearHighlight()` / `resize()`

### Callback
```javascript
bar.onRegionSelect(region => { /* region is a string or null on deselect */ });
```

---

## `LineChart.js`

**Exports:** `LineChart` (default)  
**Data source:** `dm.getTrends(countries)`  
**Section:** "Trends Over Time"

Multi-series line chart showing long-range World Bank trends from 1990–2023 for a user-configurable set of countries.

### Features
- Smooth curves using `d3.curveCatmullRom`
- Animated line drawing using `stroke-dasharray` / `stroke-dashoffset` technique
- Hover crosshair with vertical rule snapping to nearest year
- Tooltip listing all visible countries' values at the hovered year
- Metric switcher (GDP, life expectancy, population, CO₂)
- Right-side legend with country name labels at line endpoints
- Country chip UI (in `main.js`) allows adding/removing countries
- Click a line → dispatches country to main.js for cross-chart highlighting
- `resize()`

### Supported Metrics
| Key | Label |
|---|---|
| `GDP_current_US` | Total GDP (current USD) |
| `life_expectancy` | Life Expectancy (years) |
| `population` | Population |
| `CO2_emissions` | CO₂ Emissions (kt) |

### Callback
```javascript
line.onCountrySelect(country => { /* country is a string */ });
```

---

## `RadarChart.js`

**Exports:** `RadarChart` (default)  
**Data source:** `dm.getRadarData(country)`  
**Section:** "Country Profile"

Spider/radar chart comparing up to three countries simultaneously across six well-being dimensions. This is the project's **creative visualisation**, going beyond lecture examples.

### Features
- 6 axes: GDP/Capita, Social Support, Health, Freedom, Generosity, Low Corruption
- All values normalised to [0–1] against the dataset maximum, enabling fair comparison
- Up to 3 overlaid country polygons with distinct colours (`#4fc3f7`, `#ff9800`, `#66bb6a`)
- Filled semi-transparent polygons with contrasting stroke
- Animated transitions when countries change
- Circular grid lines and axis spoke lines
- Axis label hover shows raw (un-normalised) value
- Auto-populated from clicks in scatter, map, and line charts
- `resize()`

### Axes
| Axis | Data Field | Description |
|---|---|---|
| GDP / Capita | `gdp_per_capita_idx` | WHR GDP per capita index |
| Social Support | `social_support` | WHR social support score |
| Health | `healthy_life_exp` | WHR healthy life expectancy |
| Freedom | `freedom` | WHR freedom to make life choices |
| Generosity | `generosity` | WHR generosity score |
| Low Corruption | `corruption` | WHR corruption perception (higher = less corrupt) |

---

## `main.js`

**No exported class** — this is the application entry point.

Holds all mutable application state in a single `state` object, bootstraps the app, and wires every interaction between charts.

### State Object
```javascript
const state = {
    scatterYear:     2015,      // Active year for scatter + legend
    mapYear:         2015,      // Active year for map
    barYear:         2015,      // Active year for bar chart
    mapMetric:       'happiness',
    barMetric:       'happiness',
    trendMetric:     'GDP_current_US',
    trendCountries:  ['Finland', 'United States', 'India', 'Brazil', 'Nigeria'],
    radarCountries:  ['Finland', '', ''],
    scatterFiltered: false      // True when scatter shows a subset
};
```

### Boot Sequence
1. `dm.load()` and `choropleth.loadGeo()` run in parallel
2. `populateSelectors()` — fills radar country dropdowns
3. `renderAll()` — initial render of all five charts
4. Wire year buttons, dropdowns, interactions, reset, insight cards, nav scroll, scroll progress, resize

### Cross-Chart Interaction Map

| Source Event | What Happens |
|---|---|
| Scatter click (country) | Map highlights country; radar auto-fills |
| Map click (country) | Scatter highlights country; radar auto-fills |
| Bar click (region) | Scatter filtered to that region only |
| Bar deselect | Scatter restored to full dataset |
| Line click (country) | Scatter + map highlight; radar auto-fills |
| Legend click (region) | Scatter filtered; bar highlighted |
| Year button | Scatter/map/bar re-renders for new year |
| Metric dropdown | Corresponding chart re-renders |
| Radar selector | Radar re-renders with new country set |
| Insight card click | Pre-configures radar/bar/trends + callout strip |

### Key Helper Functions
| Function | Description |
|---|---|
| `pushToRadar(country)` | Adds country to next free radar slot (rotates when full) |
| `buildScatterLegend()` | Renders region colour swatches with click-to-filter |
| `buildCountryChips()` | Renders removable chips for trend countries + Add button |
| `animateCountUp(el)` | Cubic-ease count-up animation for insight stat numbers |
| `wireNavScroll()` | IntersectionObserver to highlight active nav link |
| `wireScrollProgress()` | Updates progress bar width on scroll |
| `wireResize()` | Debounced resize handler (220ms) for all charts |