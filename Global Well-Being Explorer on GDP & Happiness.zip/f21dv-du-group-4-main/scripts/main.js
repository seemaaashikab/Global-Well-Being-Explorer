/**
 * main.js
 * Application orchestration for the Global Well-Being Explorer.
 *
 * This file is the single entry point for the application. It does not export
 * any classes. Instead it:
 *
 *  1. Instantiates DataManager and all five chart classes.
 *  2. Loads CSV data and TopoJSON geography concurrently.
 *  3. Performs the initial render of every chart.
 *  4. Wires per-section year buttons (scatter/map use 2015-2019, bar uses 2015-2016).
 *  5. Wires metric dropdowns and radar country selectors.
 *  6. Implements bidirectional cross-chart interactions (scatter <-> map, bar -> scatter, etc.).
 *  7. Manages the scatter reset button visibility.
 *  8. Animates insight card count-up numbers when the conclusion section scrolls into view.
 *  9. Handles insight card clicks that update charts and smooth-scroll to the relevant section.
 * 10. Tracks scroll progress and highlights the active navigation link.
 * 11. Debounces window resize events and re-renders all charts.
 */

import { DataManager, REGION_COLOURS } from './DataManager.js';
import ScatterChart  from './ScatterChart.js';
import BarChart      from './BarChart.js';
import LineChart     from './LineChart.js';
import ChoroplethMap from './ChoroplethMap.js';
import RadarChart    from './RadarChart.js';

/* ==============================================================
   Application State
   A single mutable object that holds the current year, metric,
   and selection values for every chart. Scatter and map share
   years 2015-2019. Bar is limited to 2015-2016 because region
   data only exists in the happiness CSV for those two years.
   ============================================================== */

const state = {
    scatterYear:    2015,
    mapYear:        2015,
    barYear:        2015,
    mapMetric:      'happiness',
    barMetric:      'happiness',
    trendMetric:    'GDP_current_US',
    trendCountries: ['Finland', 'United States', 'India', 'Brazil', 'Nigeria'],
    radarCountries: ['Finland', '', ''],
    scatterFiltered: false  // true when scatter is showing a subset
};

/* ==============================================================
   Chart Instances
   Each chart is constructed once with its container and tooltip
   CSS selectors. They are re-used for the lifetime of the page.
   ============================================================== */

const dm         = new DataManager();
const scatter    = new ScatterChart('#scatter-chart',  '#scatter-tooltip');
const bar        = new BarChart('#bar-chart',           '#bar-tooltip');
const line       = new LineChart('#line-chart',         '#line-tooltip');
const choropleth = new ChoroplethMap('#map-chart',      '#map-tooltip');
const radar      = new RadarChart('#radar-chart');

/* ==============================================================
   Bootstrap
   An immediately invoked async function that loads data, renders
   all charts, and wires every interaction. If loading fails, an
   error message is injected into the page body.
   ============================================================== */

(async function boot() {
    try {
        await Promise.all([dm.load(), choropleth.loadGeo()]);
        console.log('[main] All data loaded.');
        populateSelectors();
        renderAll();
        wireYearButtons();
        wireDropdowns();
        wireInteractions();
        wireScatterReset();
        wireInsightCards();
        wireNavScroll();
        wireScrollProgress();
        wireResize();
        observeInsightSection();
        console.log('[main] Application ready.');
    } catch (err) {
        console.error('[main] Boot failed:', err);
        document.body.insertAdjacentHTML('beforeend',
            `<div style="color:#f87171;padding:2rem;text-align:center;">
                <h2>Failed to load data</h2><pre>${err.message}</pre>
             </div>`
        );
    }
})();

/* ==============================================================
   Render Functions
   Each function pulls the relevant data from DataManager using
   the current state values and passes it to the corresponding
   chart's render() method.
   ============================================================== */

/**
 * Render all five charts at once.
 * Called once during boot and again if a full refresh is ever needed.
 */

function renderAll() {
    renderScatter();
    renderMap();
    renderBar();
    renderTrends();
    renderRadar();
}


/**
 * Render the scatter plot for the current scatterYear.
 * Also rebuilds the colour legend and hides the reset button.
 */
function renderScatter() {
    scatter.render(dm.getByYear(state.scatterYear));
    buildScatterLegend();
    setScatterFiltered(false);
}

/**
 * Render the choropleth map for the current mapYear and mapMetric.
 */
function renderMap() {
    choropleth.render(dm.getByYear(state.mapYear), state.mapMetric);
}

/**
 * Render the bar chart with region averages for the current barYear and barMetric.
 */
function renderBar() {
    bar.render(dm.getRegionAverages(state.barYear, state.barMetric), state.barMetric);
}

/**
 * Render the line chart with trend data for the selected countries and metric.
 * Also rebuilds the country chip UI below the chart.
 */
function renderTrends() {
    line.render(
        dm.getTrends(state.trendCountries),
        state.trendMetric,
        buildColourMap(state.trendCountries)
    );
    buildCountryChips();
}

/**
 * Render the radar chart with up to 3 country profiles.
 * Filters out empty slots and skips countries that have no radar data.
 */
function renderRadar() {
    const datasets = state.radarCountries
        .filter(c => c)
        .map(country => {
            const vals = dm.getRadarData(country);
            return vals ? { country, values: vals } : null;
        })
        .filter(Boolean);
    radar.render(datasets);
}

/* ==============================================================
   Scatter Reset Button
   The reset button appears whenever the scatter is filtered
   (by region click or country highlight). Clicking it fully
   resets the scatter to show all countries for the current year
   and clears highlights on all connected charts.
   ============================================================== */

/**
 * Wire the scatter reset button and the double-click reset shortcut.
 */
function wireScatterReset() {
    const btn = document.getElementById('scatter-reset');
    if (!btn) return;
    btn.addEventListener('click', () => {
        renderScatter();           // full re-render from current year
        scatter.clearHighlight();
        choropleth.clearHighlight();
        bar.clearHighlight();
        setScatterFiltered(false);
    });

    // Also reset on double-click of chart area
    document.getElementById('scatter-chart')?.addEventListener('dblclick', () => {
        renderScatter();
        scatter.clearHighlight();
        choropleth.clearHighlight();
        bar.clearHighlight();
    });
}

/* Show or hide the scatter reset button. */
function setScatterFiltered(isFiltered) {
    state.scatterFiltered = isFiltered;
    const btn = document.getElementById('scatter-reset');
    if (btn) btn.style.display = isFiltered ? 'inline-flex' : 'none';
}

/* ==============================================================
   Populate Selector Dropdowns
   Fills the three radar country <select> elements with all
   available country names from the DataManager.
   ============================================================== */

/**
 * Build the <option> list for each radar country selector.
 * Pre-selects the country that matches the current state.
 */

function populateSelectors() {
    const ids = ['radar-country-1', 'radar-country-2', 'radar-country-3'];
    ids.forEach((id, i) => {
        const sel = document.getElementById(id);
        if (!sel) return;
        sel.innerHTML =
            `<option value="">-- Select country --</option>` +
            dm.countries
                .map(c => `<option value="${c}"${c === state.radarCountries[i] ? ' selected' : ''}>${c}</option>`)
                .join('');
    });
}

/* ==============================================================
   Year Button Wiring
   Each chart section (scatter, map, bar) has its own set of year
   buttons. Clicking a button updates the state and re-renders
   only the affected chart(s).
   ============================================================== */

/**
 * Generic helper that wires a group of year buttons to a state key.
 * When a button is clicked:
 *  1. Remove 'active' class from all buttons in the group.
 *  2. Add 'active' class to the clicked button.
 *  3. Update the state property with the button's data-year attribute.
 *  4. Call the provided render function.
 *
 * @param {string}   groupId  - DOM id of the button container
 * @param {string}   stateKey - Key in the state object to update (e.g. 'scatterYear')
 * @param {Function} renderFn - Function to call after updating state
 */

function wireYearGroup(groupId, stateKey, renderFn) {
    const container = document.getElementById(groupId);
    if (!container) return;
    container.querySelectorAll('.ybtn').forEach(btn => {
        btn.addEventListener('click', () => {
            container.querySelectorAll('.ybtn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            state[stateKey] = +btn.dataset.year;
            renderFn();
        });
    });
}

function wireYearButtons() {
    wireYearGroup('scatter-year-btns', 'scatterYear', () => {
        renderScatter();
        scatter.clearHighlight();
        choropleth.clearHighlight();
        bar.clearHighlight();
    });
    wireYearGroup('map-year-btns', 'mapYear', renderMap);
    wireYearGroup('bar-year-btns', 'barYear', () => {
        renderBar();
        bar.clearHighlight();
    });
}

/* ==============================================================
   Dropdown Wiring
   Each metric dropdown and radar country selector triggers a
   state update and re-render when its value changes.
   ============================================================== */

/**
 * Wire change listeners on all <select> dropdowns in the page.
 */

function wireDropdowns() {
    const mapSel = document.getElementById('map-metric');
    if (mapSel) mapSel.addEventListener('change', () => { state.mapMetric = mapSel.value; renderMap(); });

    const barSel = document.getElementById('bar-metric');
    if (barSel) barSel.addEventListener('change', () => { state.barMetric = barSel.value; renderBar(); });

    const trendSel = document.getElementById('trends-metric');
    if (trendSel) trendSel.addEventListener('change', () => { state.trendMetric = trendSel.value; renderTrends(); });

    ['radar-country-1', 'radar-country-2', 'radar-country-3'].forEach((id, i) => {
        const sel = document.getElementById(id);
        if (sel) sel.addEventListener('change', () => { state.radarCountries[i] = sel.value; renderRadar(); });
    });
}

/* ==============================================================
   Bidirectional Cross-Chart Interactions
   These callbacks create the linked behaviour between charts.
   When the user clicks on a data point in one chart, the other
   charts respond by highlighting, filtering, or updating.
   ============================================================== */

/**
 * Register all cross-chart interaction callbacks.
 */

function wireInteractions() {

    // 1. Scatter Map: click highlights both and pushes to radar
    scatter.onCountrySelect(country => {
        choropleth.highlight(country);
        pushToRadar(country);
        setScatterFiltered(true);   // show reset button
    });

    choropleth.onCountrySelect(country => {
        scatter.highlight(country);
        pushToRadar(country);
        setScatterFiltered(true);
    });

    // 2. Bar Scatter: clicking a region filters scatter to that region
    bar.onRegionSelect(region => {
        if (!region) {
            renderScatter();
            scatter.clearHighlight();
            choropleth.clearHighlight();
            setScatterFiltered(false);
        } else {
            const filtered = dm.getByYear(state.scatterYear).filter(d => d.Region === region);
            scatter.render(filtered);
            buildScatterLegend();
            setScatterFiltered(true);
        }
    });

    // 3. Line chart - click highlights country in scatter, map and radar
    line.onCountrySelect(country => {
        scatter.highlight(country);
        choropleth.highlight(country);
        pushToRadar(country);
        setScatterFiltered(true);
    });
}

/**
 * Push a country into the next free radar slot.
 * If all three slots are occupied, the oldest entry is removed (shift)
 * and the new country is added at the end (push), creating a rotating queue.
 *
 * @param {string} country - Country name to add to the radar
 */

function pushToRadar(country) {
    const idx = state.radarCountries.indexOf('');
    if (idx !== -1) {
        state.radarCountries[idx] = country;
    } else {
        state.radarCountries.shift();
        state.radarCountries.push(country);
    }
    syncRadarSelectors();
    renderRadar();
}

function syncRadarSelectors() {
    ['radar-country-1', 'radar-country-2', 'radar-country-3'].forEach((id, i) => {
        const sel = document.getElementById(id);
        if (sel) sel.value = state.radarCountries[i] || '';
    });
}

/* ==============================================================
   Scatter Legend
   Renders colour swatches for each region below the scatter chart.
   Clicking a swatch filters the scatter to that region only.
   Clicking the same swatch again restores the full view.
   ============================================================== */

/**
 * Build the scatter legend with one swatch per region.
 * Each swatch is clickable and filters/restores the scatter plot.
 */

function buildScatterLegend() {
    const el = document.getElementById('scatter-legend');
    if (!el) return;
    el.innerHTML = Object.entries(REGION_COLOURS).map(([region, colour]) =>
        `<span class="legend-item" data-region="${region}">
            <span class="legend-swatch" style="background:${colour};"></span>
            ${region}
         </span>`
    ).join('');

    el.querySelectorAll('.legend-item').forEach(item => {
        item.addEventListener('click', () => {
            const region   = item.dataset.region;
            const isActive = item.classList.contains('active');

            el.querySelectorAll('.legend-item').forEach(i => i.classList.remove('active'));

            if (isActive) {
                renderScatter();
                bar.clearHighlight();
                setScatterFiltered(false);
            } else {
                item.classList.add('active');
                const filtered = dm.getByYear(state.scatterYear).filter(d => d.Region === region);
                scatter.render(filtered);
                buildScatterLegend();
                document.querySelector(`.legend-item[data-region="${region}"]`)?.classList.add('active');
                bar.highlight(region);
                setScatterFiltered(true);
            }
        });
    });
}

/* ==============================================================
   Trend Country Chips
   Renders removable tag chips below the line chart, one per
   selected country. Also provides an "+ Add" button that opens
   a temporary dropdown to pick a new country.
   ============================================================== */

/**
 * Build the country chip UI for the trends section.
 * Each chip shows the country name with a colour dot and an "x" button
 * to remove it. The "+ Add" button appends a temporary <select> that
 * lists all available countries not yet selected.
 */

function buildCountryChips() {
    const container = document.getElementById('trends-country-chips');
    if (!container) return;
    container.innerHTML = '';

    const colMap = buildColourMap(state.trendCountries);

    state.trendCountries.forEach(country => {
        const chip = document.createElement('span');
        chip.className = 'chip';
        chip.style.setProperty('--chip-color', colMap[country] || '#aaa');

        const label = document.createElement('span');
        label.textContent = country;

        const rm = document.createElement('span');
        rm.className = 'chip-remove';
        rm.textContent = 'x';
        rm.title = 'Remove';
        rm.addEventListener('click', () => {
            state.trendCountries = state.trendCountries.filter(c => c !== country);
            renderTrends();
        });

        chip.appendChild(label);
        chip.appendChild(rm);
        container.appendChild(chip);
    });

    const addBtn = document.createElement('button');
    addBtn.className = 'chip chip-add';
    addBtn.textContent = '+ Add';
    addBtn.addEventListener('click', () => {
        const existing = document.getElementById('chip-add-select');
        if (existing) { existing.remove(); return; }

        const available = [...new Set(dm.trends.map(d => d.Country))]
            .filter(c => !state.trendCountries.includes(c)).sort();

        const sel = document.createElement('select');
        sel.id = 'chip-add-select';
        sel.className = 'styled-select';
        sel.innerHTML = `<option value="">-- choose --</option>` +
            available.map(c => `<option value="${c}">${c}</option>`).join('');

        sel.addEventListener('change', () => {
            if (sel.value && !state.trendCountries.includes(sel.value)) {
                state.trendCountries.push(sel.value);
                renderTrends();
            }
            sel.remove();
        });
        sel.addEventListener('blur', () => setTimeout(() => sel.remove(), 200));

        container.appendChild(sel);
        sel.focus();
    });
    container.appendChild(addBtn);
}

function buildColourMap(countries) {
    const palette = d3.schemeTableau10;
    const map = {};
    countries.forEach((c, i) => { map[c] = palette[i % palette.length]; });
    return map;
}

/* ==============================================================
   Interactive Insight Cards
   The conclusion section contains six clickable insight cards.
   Clicking a card:
    - Highlights it visually (active state).
    - Updates the callout strip with a contextual hint.
    - Sets up a "Go to chart" link that smooth-scrolls to the
      relevant section.
    - Optionally triggers a chart action (e.g. loads specific
      countries into radar, switches bar metric, switches trends metric).
   ============================================================== */

/**
 * Wire click listeners on all insight cards in the conclusion section.
 */

function wireInsightCards() {
    const cards       = document.querySelectorAll('.insight-card');
    const callout     = document.getElementById('insight-callout');
    const calloutText = document.getElementById('callout-text');
    const calloutLink = document.getElementById('callout-link');

    cards.forEach(card => {
        card.addEventListener('click', () => {
            const wasActive = card.classList.contains('active');
            cards.forEach(c => c.classList.remove('active'));

            if (wasActive) {
                if (callout) callout.classList.remove('active');
                return;
            }

            card.classList.add('active');

            const section    = card.dataset.section;
            const hint       = card.dataset.hint || '';
            const radarA     = card.dataset.radarA;
            const radarB     = card.dataset.radarB;
            const barMetric  = card.dataset.barMetric;
            const trendsMet  = card.dataset.trendsMetric;

            // Update callout strip
            if (callout && calloutText) {
                calloutText.textContent = hint;
                callout.classList.add('active');
            }

            // Update "Go to chart" link. smooth scroll on click
            if (calloutLink) {
                calloutLink.onclick = (e) => {
                    e.preventDefault();
                    const target = document.getElementById(section);
                    if (target) {
                        const navH = document.getElementById('story-nav')?.offsetHeight || 56;
                        const top  = target.getBoundingClientRect().top + window.scrollY - navH - 16;
                        window.scrollTo({ top, behavior: 'smooth' });
                    }
                };
            }

            // Trigger contextual chart actions
            if (radarA && radarB) {
                state.radarCountries = [radarA, radarB, ''];
                syncRadarSelectors();
                renderRadar();
            }

            if (barMetric) {
                state.barMetric = barMetric;
                const barSel = document.getElementById('bar-metric');
                if (barSel) barSel.value = barMetric;
                renderBar();
            }

            if (trendsMet) {
                state.trendMetric = trendsMet;
                const trendSel = document.getElementById('trends-metric');
                if (trendSel) trendSel.value = trendsMet;
                renderTrends();
            }
        });
    });
}

/* ==============================================================
   Count-Up Animation for Insight Numbers
   When the conclusion section scrolls into view, the stat numbers
   (e.g. "0.79", "30", "4.75") animate from 0 to their target value
   using a cubic ease-out curve.
   ============================================================== */

/**
 * Animate a single element's text content from 0 to its target number.
 * The target and decimal places are read from the element's data attributes.
 * Uses requestAnimationFrame for smooth 60fps animation.
 *
 * @param {HTMLElement} el - The element whose textContent will be animated.
 *                           Must have data-target (number) and data-dec (integer) attributes.
 */

function animateCountUp(el) {
    const target   = parseFloat(el.dataset.target);
    const decimals = parseInt(el.dataset.dec) || 0;
    const duration = 1600;
    const start    = performance.now();

    function step(now) {
        const t    = Math.min((now - start) / duration, 1);
        const ease = 1 - Math.pow(1 - t, 3);
        el.textContent = (ease * target).toFixed(decimals);
        if (t < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
}

function observeInsightSection() {
    const section = document.getElementById('conclusion');
    if (!section) return;
    let fired = false;
    const obs = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && !fired) {
            fired = true;
            document.querySelectorAll('.insight-num').forEach((el, i) => {
                setTimeout(() => animateCountUp(el), i * 100);
            });
        }
    }, { threshold: 0.2 });
    obs.observe(section);
}

/* ==============================================================
   Navigation Scroll Highlighting
   Uses IntersectionObserver to detect which story section is
   currently visible in the viewport and highlights the
   corresponding link in the fixed navigation bar.
   ============================================================== */

/**
 * Wire the IntersectionObserver that tracks visible sections
 * and toggles the 'active' class on the matching nav link.
 */

function wireNavScroll() {
    const sections = document.querySelectorAll('.story-section');
    const links    = document.querySelectorAll('.nav-link');
    const navH     = document.getElementById('story-nav')?.offsetHeight || 56;

    const obs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.id;
                links.forEach(l => l.classList.toggle('active', l.dataset.section === id));
            }
        });
    }, {
        rootMargin: `-${navH + 10}px 0px -50% 0px`,
        threshold: 0.05
    });

    sections.forEach(s => obs.observe(s));
}

/* ==============================================================
   Scroll Progress Bar
   A thin gradient bar at the bottom of the nav that fills from
   0% to 100% as the user scrolls through the page.
   ============================================================== */

/**
 * Wire a passive scroll listener that updates the progress bar width.
 */

function wireScrollProgress() {
    const bar = document.getElementById('scroll-progress-bar');
    if (!bar) return;
    window.addEventListener('scroll', () => {
        const total = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.width = (total > 0 ? Math.min(100, (window.scrollY / total) * 100) : 0) + '%';
    }, { passive: true });
}

/* ==============================================================
   Resize Handling
   Debounces window resize events (220ms delay) and calls
   resize() on every chart so they recalculate their SVG
   dimensions to fit the new container width.
   ============================================================== */

/**
 * Wire a debounced resize handler that re-renders all charts.
 */
function wireResize() {
    let timer;
    window.addEventListener('resize', () => {
        clearTimeout(timer);
        timer = setTimeout(() => {
            scatter.resize();
            bar.resize();
            line.resize();
            choropleth.resize();
            radar.resize();
        }, 220);
    });
}
