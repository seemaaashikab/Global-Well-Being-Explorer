/**
 * ChoroplethMap.js
 * Interactive world map coloured by a selected well-being metric.
 *
 * This chart is used in the "World Map" section. It renders a Natural Earth
 * projected world map where each country is filled with a colour representing
 * its value for the currently selected metric (happiness, GDP per capita,
 * life expectancy, or internet access).
 *
 * Features:
 *  - Natural Earth projection via D3 and TopoJSON
 *  - Four sequential colour scales (one per metric), each with a fixed
 *    domain so colours remain comparable across years
 *  - Zoom and pan using D3's zoom behaviour (scroll to zoom, drag to pan)
 *  - Ocean background and graticule grid lines
 *  - Hover tooltip showing country name and key indicators
 *  - Click a country to dispatch its name for cross-chart highlighting
 *  - Colour legend bar generated on a canvas element
 *  - highlight(country) / clearHighlight() for cross-chart interaction
 *  - resize() recalculates the projection when the container changes
 *
 * Data source: DataManager.getByYear(year)
 * Geography: libs/topojson/countries-110m.json (loaded once via loadGeo())
 */

class ChoroplethMap {

    #container;
    #svg;
    #g;
    #tooltip;
    #projection;
    #path;
    #colourScale;
    #zoom;

    #width;
    #height;

    #data    = [];
    #dataMap = new Map();
    #metric  = 'happiness';
    #worldGeo = null;
    #onSelectCb = null;

    /** Metric configuration: label, d3 interpolator, fixed domain */
    static CFG = {
        happiness:       { label: 'Happiness Score',   interp: d3.interpolateYlGnBu,  domain: [2.5, 8] },
        gdp_per_capita:  { label: 'GDP per Capita',    interp: d3.interpolateViridis,  domain: [200, 80000] },
        life_expectancy: { label: 'Life Expectancy',   interp: d3.interpolateRdYlGn,   domain: [45, 85] },
        internet_users:  { label: 'Internet Access %', interp: d3.interpolatePurples,  domain: [0, 100] }
    };

    /**
     * @param {string} containerSel
     * @param {string} tooltipSel
     */
    constructor(containerSel, tooltipSel) {
        this.#container = document.querySelector(containerSel);
        this.#tooltip   = d3.select(tooltipSel);
        this.#initSvg();
    }

    /* Public API  */
    /** Load TopoJSON geometry once before first render. */
    async loadGeo() {
        const world = await d3.json('libs/topojson/countries-110m.json');
        this.#worldGeo = topojson.feature(world, world.objects.countries);
        console.log(`[ChoroplethMap] Geometry loaded: ${this.#worldGeo.features.length} features`);
    }

    /**
     * Render or update the map.
     * @param {Array}  data   - Rows from DataManager.getByYear()
     * @param {string} metric - Property to colour by
     */
    render(data, metric) {
        this.#data   = data;
        this.#metric = metric || this.#metric;
        this.#buildDataMap();
        this.#updateColourScale();
        this.#drawCountries();
        this.#drawLegend();
    }

    /** Stroke-highlight a single country. */
    highlight(country) {
        this.#g.selectAll('.country')
            .transition().duration(300)
            .attr('stroke', d => this.#matchName(d) === country ? '#fff' : '#1a1f2e')
            .attr('stroke-width', d => this.#matchName(d) === country ? 2 : 0.3);
    }

    clearHighlight() {
        this.#g.selectAll('.country')
            .transition().duration(300)
            .attr('stroke', '#1a1f2e').attr('stroke-width', 0.3);
    }

    onCountrySelect(cb) { this.#onSelectCb = cb; }

    resize() {
        this.#initSvg();
        if (this.#worldGeo) this.render(this.#data, this.#metric);
    }

    /* Private */
    #initSvg() {
        const rect = this.#container.getBoundingClientRect();
        this.#width  = rect.width;
        this.#height = Math.max(450, rect.height - 32);

        d3.select(this.#container).select('svg').remove();

        this.#svg = d3.select(this.#container)
            .append('svg')
            .attr('width',  this.#width)
            .attr('height', this.#height);

        this.#g = this.#svg.append('g');

        this.#projection = d3.geoNaturalEarth1()
            .fitSize([this.#width, this.#height], { type: 'Sphere' });

        this.#path = d3.geoPath().projection(this.#projection);

        // Ocean background
        this.#g.append('path')
            .datum({ type: 'Sphere' })
            .attr('d', this.#path)
            .attr('fill', '#0d1520');

        // Graticule
        this.#g.append('path')
            .datum(d3.geoGraticule()())
            .attr('d', this.#path)
            .attr('fill', 'none')
            .attr('stroke', '#1e2a3a')
            .attr('stroke-width', 0.4);

        this.#zoom = d3.zoom()
            .scaleExtent([1, 10])
            .on('zoom', (ev) => this.#g.attr('transform', ev.transform));

        this.#svg.call(this.#zoom);
    }

    #buildDataMap() {
        this.#dataMap.clear();
        for (const row of this.#data) this.#dataMap.set(row.Country, row);
    }

    #updateColourScale() {
        const cfg = ChoroplethMap.CFG[this.#metric] || ChoroplethMap.CFG.happiness;
        this.#colourScale = d3.scaleSequential(cfg.interp).domain(cfg.domain);
    }

    #drawCountries() {
        if (!this.#worldGeo) return;
        const self = this;

        const countries = this.#g.selectAll('.country')
            .data(this.#worldGeo.features, d => d.id);

        const enter = countries.enter()
            .append('path')
            .attr('class', 'country')
            .attr('d', this.#path)
            .attr('stroke', '#1a1f2e')
            .attr('stroke-width', 0.3)
            .attr('fill', '#2d3548');

        enter.merge(countries)
            .on('mouseover', function(event, d) {
                d3.select(this).raise().attr('stroke', '#fff').attr('stroke-width', 1.5);
                self.#showTooltip(event, d);
            })
            .on('mousemove', (event) => this.#moveTooltip(event))
            .on('mouseout', function() {
                d3.select(this).attr('stroke', '#1a1f2e').attr('stroke-width', 0.3);
                self.#tooltip.style('opacity', 0);
            })
            .on('click', (event, d) => {
                const name = this.#matchName(d);
                if (name && this.#onSelectCb) this.#onSelectCb(name);
            })
            .transition().duration(700)
            .attr('fill', d => {
                const name = this.#matchName(d);
                if (!name) return '#2d3548';
                const row = this.#dataMap.get(name);
                if (!row || row[this.#metric] == null) return '#2d3548';
                return this.#colourScale(row[this.#metric]);
            });
    }

    #drawLegend() {
        const legendEl = document.getElementById('map-legend-bar');
        if (!legendEl) return;
        const cfg = ChoroplethMap.CFG[this.#metric] || ChoroplethMap.CFG.happiness;
        const canvas = document.createElement('canvas');
        canvas.width = 300; canvas.height = 12;
        const ctx = canvas.getContext('2d');
        const grad = ctx.createLinearGradient(0, 0, 300, 0);
        for (let i = 0; i <= 10; i++) {
            const t = i / 10;
            grad.addColorStop(t, this.#colourScale(cfg.domain[0] + t * (cfg.domain[1] - cfg.domain[0])));
        }
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 300, 12);

        const fmt = d3.format('.2s');
        legendEl.innerHTML = `
            <span class="legend-label">${fmt(cfg.domain[0])}</span>
            <img class="legend-bar" src="${canvas.toDataURL()}" alt="colour scale">
            <span class="legend-label">${fmt(cfg.domain[1])}</span>
            <span class="legend-label legend-metric">${cfg.label}</span>
        `;
    }

    /** Matching a TopoJSON feature to our data by country name. */
    #matchName(feature) {
        const topo = feature.properties?.name || '';
        if (this.#dataMap.has(topo)) return topo;
        for (const key of this.#dataMap.keys()) {
            if (key === topo || topo.includes(key) || key.includes(topo)) return key;
        }
        return null;
    }

    #showTooltip(event, d) {
        const name = this.#matchName(d);
        const row  = name ? this.#dataMap.get(name) : null;
        const fmtM = d3.format('$,.0f');

        this.#tooltip.style('opacity', 1).html(`
            <div class="tt-title">${name || d.properties?.name || 'Unknown'}</div>
            ${row ? `
            <div class="tt-row"><span class="tt-label">Happiness</span><span>${row.happiness != null ? row.happiness.toFixed(2) : 'N/A'}</span></div>
            <div class="tt-row"><span class="tt-label">GDP/capita</span><span>${row.gdp_per_capita != null ? fmtM(row.gdp_per_capita) : 'N/A'}</span></div>
            <div class="tt-row"><span class="tt-label">Life Exp.</span><span>${row.life_expectancy != null ? row.life_expectancy.toFixed(1) + ' yrs' : 'N/A'}</span></div>
            <div class="tt-row"><span class="tt-label">Internet</span><span>${row.internet_users != null ? row.internet_users.toFixed(1) + '%' : 'N/A'}</span></div>
            <div class="tt-row"><span class="tt-label">Region</span><span>${row.Region || 'N/A'}</span></div>
            ` : '<div style="color:#8b93a7;margin-top:4px">No data available</div>'}
        `);
    }

    #moveTooltip(event) {
        const rect = this.#container.getBoundingClientRect();
        this.#tooltip
            .style('left', (event.clientX - rect.left + 16) + 'px')
            .style('top',  (event.clientY - rect.top  - 10) + 'px');
    }
}

export default ChoroplethMap;
